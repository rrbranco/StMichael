#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include <linux/mman.h>
#include "StJude_lkm.h"
#include "StJude_string_util.h"
#include "StJude_response.h"

#ifndef USE_OLD_EXECEVE
#include <linux/smp_lock.h>
#include "StJude_execve_util.h"
#endif

/* 
   This response will execute the program pointed to by sjfilename
   with the command line arguments defined in sjargv (remember argv[0]
   is the filename). 

   This provides the opportunity to redirect the execution to a application
   of our choosing. This application executes in the context of the process
   that has generated the event. This affords us a great opportunity to
   further analyze the situation from the point-of-view of the potential
   attacker (maybe take a snapshot of the history and filesystem), 
   or initiate a response.

   It is likely to be noted by an astute individual that this also affords
   the opportunity to counter-attack the attacker, using their control
   channel against them. This is a distinct possibility, but something I
   want to personally discourage.

   Additionally, make note that the process spawned with run with the
   privileges the attacker tried to acquire. This means:

            1) Do not execeve anything without first dropping privileges.
 
			Else Endless loop.

            2) Be Very Careful.

                        

   --Tim
 */

extern int sjexecve;
char *sjfilename = RESPONSE_PROG; 
char *sjargv[] = { RESPONSE_PROG,NULL } ;
//char *sjfilename = "/bin/dmesg"; 
//char *sjargv[] = { "/bin/dmesg",NULL } ;


inline int sj_do_response (char *filename, char **argv, char **envp, struct pt_regs *regs)
{
 
    int sj_res,size,argc;
    char *userfilename;
    char **userargs;  

   size = sjp_l_strnlen(sjfilename,BUFFSIZE)+1;
   userfilename = sjp_l_malloc(size); 

   if (!userfilename)
	return 0;
   
   copy_to_user(userfilename,sjfilename,size);


   /* Forgive me father, for I have sinned. */
   argc = ( size = (sjp_l_strnlen((char *) sjargv,BUFFSIZE) ) ) / sizeof(void *) ;
 
   userargs = sjp_l_malloc(size + sizeof(void*)); 
   copy_to_user(userargs[argc],sjargv[argc],sizeof(void *));
   for (sj_res = 0;sj_res < argc;sj_res++)
	{
            size = sjp_l_strnlen(sjargv[sj_res],BUFFSIZE) + 1;
            userargs[sj_res] = sjp_l_malloc(size);
            copy_to_user(userargs[sj_res],sjargv[sj_res],size);

        } 
   
current->uid = current->euid = current->fsuid = current->suid = RESPONSE_UID;

     regs->ecx = (long) userargs;
     regs->ebx = (long) userfilename;
     {
        char * filename;

	lock_kernel();
        filename = getname((char *) regs->ebx);
        sj_res = PTR_ERR(filename);
        if (IS_ERR(filename))
             goto sj_execve_out;
	sj_res = sj_internal_execve(filename, (char **) userargs, 
                                   (char **) envp, regs);
        if (sj_res == 0)
#if defined(PT_DTRACE)
                current->ptrace &= ~PT_DTRACE;
#else
		current->flags &= ~PF_DTRACE;
#endif
        putname(filename);
sj_execve_out:
	unlock_kernel();
    }

  return 0;
}

int sj_do_landmine_response (char *filename, char **argv, char **envp)
{
    send_sig(SIGKILL,current,1);
    return 0;
}
