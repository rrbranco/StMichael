#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include "StJude_lkm.h"

SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];


struct sj_argv_memory *
create_argv_memory(pid_t pid, char argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE])
{
    struct sj_argv_memory *memory;
    int             i,
                    j;

    memory = kmalloc(sizeof(*memory), GFP_KERNEL);

    if (memory) {
	memory->pid = pid;
	for (i = 0; i < MAX_KEY_ELEMENTS + 1; i++)
	    for (j = 0; j < BUFFSIZE; j++)
		memory->argv[i][j] = argv[i][j];
	memory->next = sj_argv_memory_hash[memory->pid % SJ_MEMORY_HASH];
	sj_argv_memory_hash[memory->pid % SJ_MEMORY_HASH] = memory;
	return memory;
    } else {
#ifdef DEBUG
	printk("<1>(STJUDE) Unable to allocate memory structure\n");
#endif
    }
    return NULL;

}

/*
 * 
 * Get a priv record based on its pid.  (DUH!)
 * 
 */


inline struct sj_argv_memory *
get_argv_memory(struct task_struct *task)
{
    struct sj_argv_memory *memory;
    pid_t pid;

    if (!task)
       { return NULL; }
   
    pid = task->pid;
     
    memory = sj_argv_memory_hash[pid % SJ_MEMORY_HASH];

    while (memory != NULL) {

	if (memory->pid == pid)
	    break;

	memory = memory->next;

    }

    /* Memory Hack to handle a Vfork Condition. */

    if (memory == NULL) {
	struct sj_argv_memory *parent_memory;

        /* This is not nice, and could be messy... 
           but we were called with a read lock, before
           we do anything we have to release that read lock and get
           a write lock, then re-install the read lock. 

         */


	parent_memory = get_argv_memory(task->p_pptr);
	if (parent_memory) {
	    memory = create_argv_memory(task->pid, parent_memory->argv);
#ifdef DEBUG
	    if (!memory)
		printk
		    ("(StJude) sj_fork: Something bad happened, I can't remember argv's.\n");
#endif
	} else {
#ifdef DEBUG
	    printk
		("(StJude) suid_hack: Something bad happened. I can't find my parent's (%d) memory.\n",
		 task->p_pptr->pid);
#endif
	}

         
    }
    return memory;
}

inline int destroy_argv_memory(pid_t pid)
{
    struct sj_argv_memory *memory;
    struct sj_argv_memory *prev;

    prev = NULL;
    memory = sj_argv_memory_hash[pid % SJ_MEMORY_HASH];

    while (memory != NULL) {

	if (memory->pid == pid)
	    break;

	prev = memory;
	memory = memory->next;

    }


    if (memory != NULL) {
	if (prev != NULL)
	    prev->next = memory->next;
	else
	    sj_argv_memory_hash[pid % SJ_PRIV_HASH] = memory->next;

	kfree(memory);

    } else {
	return 0;
    }				/*
				 * * Tried to delete a record that doesn't
				 * exit 
				 */

    return 1;
}
