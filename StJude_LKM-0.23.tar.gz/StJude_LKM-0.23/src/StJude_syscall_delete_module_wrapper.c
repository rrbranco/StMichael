#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include "StJude_lkm.h"
#include "StJude_string_util.h"


extern SJ_PRIV *sj_priv_hash[SJ_PRIV_HASH];
extern SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];

extern SJ_RULEBASE sj_rulebase[];

/* We are busy! Go away! */
int
sj_delete_module (const char *name)
{
   
#if defined(USE_STMICHAEL) && !defined(LEARNING)
   int delete_module_return;
#endif


#ifdef DEBUG
#ifdef __SMP__
read_lock(&tasklist_lock);
#endif

printk(" -----------------------------SYSCALL BY %d------------------------\n",current->pid);

#ifdef __SMP__
read_unlock(&tasklist_lock);
#endif
#endif

#if defined(USE_STMICHAEL) && !defined(LEARNING)

   if (name != NULL && *name != '\0')
   {
   if ( ! sjp_l_strncmp(name,"StJude", 12) )
      {
#if defined(CLOAK)
         return -ENOENT;
#else
	 return -EBUSY;
#endif
      }

   if ( ! sjp_l_strncmp(name,"+",1) )
      {
        return -EBUSY;
      }
    }


#ifdef FSCHECK 
#ifdef __SMP__
   write_lock(&fscheck_lock);
#endif
   check_fscheck_records();
#ifdef __SMP__
   write_unlock(&fscheck_lock);
#endif
#endif


   delete_module_return = (*orig_delete_module)(name);
   
  /* 
     Verify that the syscall table is the same. 
     If its changed then respond 

     We could probably make this a function in itself, but
     why spend the extra time making a call?

   */

#ifdef USE_CHECKSUM
   sm_check_dependency_integrity();
#endif

   if (delete_module_return == 0)
  	 sm_remove_module_list(name);

   sm_check_sys_call_integrity();

   sm_check_module_list();

#ifdef USE_CHECKSUM
   sm_check_ktext_integrity();
#endif

  return delete_module_return;

#else

#if defined(LEARNING)
   return (*orig_delete_module)(name);
#else
  return -EBUSY;
#endif

#endif

}

void sm_delete_module_end ( void )
{ return; }


