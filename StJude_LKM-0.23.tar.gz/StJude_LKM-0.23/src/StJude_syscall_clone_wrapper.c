#define __KERNEL__


/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include "StJude_lkm.h"


extern SJ_PRIV *sj_priv_hash[SJ_PRIV_HASH];
extern SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];

extern SJ_RULEBASE sj_rulebase[];

/* See fork */
int
sj_clone (struct pt_regs regs)
{
  int sj_clone_return;
  struct sj_argv_memory *memory;

#ifdef __SMP__
read_lock(&sj_running);
read_lock(&tasklist_lock);
#endif

#ifdef DEBUG
printk(" -----------------------------SYSCALL BY %d------------------------\n",current->pid);
#endif
#ifdef DEBUG
       printk("  (StJude) sj_cline: Entered sj_clone()\n");
#endif

#ifdef __SMP__
read_unlock(&tasklist_lock);
#endif

  sj_clone_return = (*orig_clone) (regs);

#ifdef __SMP__
read_lock(&tasklist_lock);
write_lock(&argv_memory_lock); 
#endif

memory = get_argv_memory(current);

#ifdef DEBUG
if (!(memory && create_argv_memory(sj_clone_return,memory->argv)))
           printk("(StJude) sj_Clone: Something bad happened, I can't remember argv's.\n");
#endif

#ifdef __SMP__
write_unlock(&argv_memory_lock); 
#endif

#if defined(CHECK_CAP)
if (((!current->euid && current->uid && current->suid)) ||
		( current->cap_effective & ( SJ_CAP_MASK ^ 0xFFFFFFFF ) ||
		  current->cap_permitted & ( SJ_CAP_MASK ^ 0xFFFFFFFF ) ))
#else
if (!(current->euid && current->uid && current->suid))
#endif
       {  
      struct sj_priv *child;
      struct sj_priv *parent;

#ifdef __SMP__
write_lock(&priv_lock);
#endif
      parent = get_priv_record(current->pid);
      
      if (!parent) {
#ifdef __SMP__
            write_lock(&argv_memory_lock);
#endif
            suid_hack(current);  
#ifdef __SMP__
            write_unlock(&argv_memory_lock);
#endif

           parent = get_priv_record(current->pid);
#ifdef DEBUG
	   if (!parent)
		{
		   printk("(StJude) sj_fork: Brace yourself, we are going to crash!\n");
                }
#endif
        }

/* The way we will handle forks is simple.. We create a priv thingy
   but with the 0 as its index. Then we assign the value of the parent's 
   priv record to the child.
 */

   if (sj_clone_return > 0) {
  
           if (parent) 
                  child = create_priv_record(sj_clone_return,parent->restriction->r_index); 
            else
                  child = create_priv_record(sj_clone_return,0); 
    

    }

#ifdef __SMP__
write_unlock(&priv_lock);
#endif

 } 

#ifdef __SMP__
read_unlock(&tasklist_lock);
read_unlock(&sj_running);
#endif


  return sj_clone_return;
}

