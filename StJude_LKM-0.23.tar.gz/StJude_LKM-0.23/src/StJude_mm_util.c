#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include "StJude_lkm.h"

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0) 

/*
 * Copied from linux/fs/array.c 
 */


static unsigned long get_phys_addr(struct task_struct *p, unsigned long ptr)
{
    pgd_t          *page_dir;
    pmd_t          *page_middle;
    pte_t           pte;

    if (!p || !p->mm || ptr >= TASK_SIZE)
	return 0;
    /*
     * Check for NULL pgd .. shouldn't happen! 
     */
    if (!p->mm->pgd) {
#ifdef DEBUG
	printk("<1>get_phys_addr: pid %d has NULL pgd!\n", p->pid);
#endif
	return 0;
    }

    page_dir = pgd_offset(p->mm, ptr);
    if (pgd_none(*page_dir))
	return 0;
    if (pgd_bad(*page_dir)) {
#ifdef DEBUG
	printk("<1>bad page directory entry %08lx\n", pgd_val(*page_dir));
#endif
	pgd_clear(page_dir);
	return 0;
    }
    page_middle = pmd_offset(page_dir, ptr);
    if (pmd_none(*page_middle))
	return 0;
    if (pmd_bad(*page_middle)) {
#ifdef DEBUG
	printk("<1>bad page middle entry %08lx\n", pmd_val(*page_middle));
#endif
	pmd_clear(page_middle);
	return 0;
    }
    pte = *pte_offset(page_middle, ptr);
    if (!pte_present(pte))
	return 0;
    return pte_page(pte) + (ptr & ~PAGE_MASK);
}

/*
 * Compiler will complain that we don't call this function. We will.. We just
 * don't.. yet. 
 */

static int
get_array(struct task_struct *p, unsigned long start, unsigned long end,
	  char *buffer)
{
    unsigned long   addr;
    int             size = 0,
                    result = 0;
    char            c;

    if (start >= end)
	return result;
    for (;;) {
	addr = get_phys_addr(p, start);
	if (!addr)
	    return result;
	do {
	    c = *(char *) addr;
	    if (!c)
		result = size;
	    if (size < PAGE_SIZE)
		buffer[size++] = c;
	    else
		return result;
	    addr++;
	    start++;
	    if (!c && start >= end)
		return result;
	} while (addr & ~PAGE_MASK);
    }
    return result;
}

#endif
