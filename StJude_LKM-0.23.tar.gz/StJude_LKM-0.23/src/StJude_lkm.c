#define MODULE
#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>

#ifdef HIDDEN_SYS_CALL_TABLE
#include <asm/processor.h>
#endif

#include "StJude_lkm.h"
#include "StJude_string_util.h"


#if !defined(LEARNING)

#define IS_IN_KERNEL_TEXT(addr)\
        (addr > (long)sj_s_text && addr < (long)sj_e_text) ? (1) : (0)

void * sj_s_text;
void * sj_e_text;

#endif

extern SJ_PRIV *sj_priv_hash[SJ_PRIV_HASH];
extern SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];

extern SJ_RULEBASE sj_rulebase[];


#ifdef HIDDEN_SYS_CALL_TABLE
extern asmlinkage long sys_exit(int error_code);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,9)
#ifdef MODULE_LICENSE
MODULE_LICENSE("GPL");
#endif
#endif

int
init_module(void)
{
    struct task_struct *p;
    struct task_struct *inittask;

#if !defined(LEARNING)
    struct module *m, **v;
    struct module_symbol *s;
    extern struct module **eml;
    extern struct module *iml;
#endif

    struct sj_argv_memory *memory;
    int             i;

    /*
     * Our memory is not cleared for us. We need to init our hashes so that
     * each hash is like null. 
     */

    for (i = 0; i < SJ_PRIV_HASH; i++)
	sj_priv_hash[i] = NULL;

    for (i = 0; i < SJ_MEMORY_HASH; i++)
	sj_argv_memory_hash[i] = NULL;


    sjp_l_print("--=={ Loading %s }\n", VERSION);

#ifdef HIDDEN_SYS_CALL_TABLE
    // In the infinite wisdom of someone, the sys_call_table
    // variable is no longer exported. I suspect this was
    // an attempt to foil the developers of kernel rootkits.
    // Unfortunitely, this is an example of when obscurit
    // does not infact do anything to improve security. The
    // fact of the matter is that the sys_call_table is easily
    // findable. All it does it make more work. Bah.
    //

    {
	unsigned long ptr;
	extern int loops_per_jiffy;

	sys_call_table = NULL;
	for (ptr = (unsigned long) &loops_per_jiffy;
			ptr < (unsigned long) &boot_cpu_data; ptr += sizeof(void *))
	{
		unsigned long *p;
		p = (unsigned long *) ptr;
		if (p[1] == (unsigned long) sys_exit)
		{
			sys_call_table = (void **) p;
			break;
		}
        } 

	if (!sys_call_table)
	{
		printk("Cant find the sys_call_table. Aborting load. Feel safe to rmmod.\n");
		return 0;
	}

     }

#endif

#if !defined(LEARNING)

    sj_s_text = (void *) ( PAGE_OFFSET | 0x00100000 );
    for (m = THIS_MODULE; m->next != NULL; m = m->next );
    for (s = m->syms; s->name; s++);
    	(unsigned int) sj_e_text = (unsigned int) s;
    
    v = (struct module **) (++m);
#if defined(CLOAK)
    *v = (THIS_MODULE)->next;
    (THIS_MODULE)->nsyms = 0;
#endif

    iml = NULL;
    eml = v;


    for (i = 0; i < NR_syscalls; i++)
	    if (!IS_IN_KERNEL_TEXT((long)sys_call_table[i]))
	    {
		    printk("(STJUDE) Possible LKM Rootkit Detected during load.\n");
    		    printk("(STJUDE) Unable to perform Recovery. Load of StJude Aborted.\n");
		    printk("(STJUDE) If this message is being erronously generated, Read the NOTE in StJude_lkm.c\n");

		    return -1;
  	    }
#endif

    /*
     * Now to "Pardon" all running processes. We are doing this (kludge)
     * because we need some starting point. We could do the hard thing and
     * "figure" out the initial restrictions for our processes.
     * 
     * This is a TODO thing. If we do do this, then we can detect network
     * based root compromises. Wouldn't that be fun?
     * 
     * If we fail here, we abort -- leaving our kernel nice and working.
     * 
     */
#ifdef __SMP__

    /* Initilize our Spinlocks to Unlocked... */
    rwlock_init(&sj_running);
    rwlock_init(&priv_lock);
    rwlock_init(&argv_memory_lock);

    /* Lock the tasklist while we muck with it. */
    read_lock(&tasklist_lock);
#endif

    p = (inittask = &(init_task_union.task))->next_task;
    do {
	char            null_argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE] =
	    NULL_ARGV;
	if (!p)
	    break;		/*
				 * healthy paranoia 
				 */

	memory = create_argv_memory(p->pid, null_argv);
	if (!memory) {
	    sjp_l_print("(StJude) Unable to Init StJude. Aborting.\n");
	    return 1;
	}

	if (!(p->uid && p->euid && p->suid)) {
	    struct sj_priv *priv;

	    priv = create_priv_record(p->pid, 1);
	    if (!priv) {
		sjp_l_print("(StJude): Unable to Init StJude. Aborting.\n");
		return 1;
	    }
	}
	p = p->next_task;
    } while (p && p != inittask);

#ifdef __SMP__
    read_unlock(&tasklist_lock);
#endif

    orig_do_execve = sys_call_table[__NR_execve];

    sys_call_table[__NR_execve] = sj_do_execve;

    orig_fork = sys_call_table[__NR_fork];
    orig_vfork = sys_call_table[__NR_vfork];
    orig_clone = sys_call_table[__NR_clone];
    orig_exit = sys_call_table[__NR_exit];
    orig_setuid = sys_call_table[__NR_setuid];
    orig_setreuid = sys_call_table[__NR_setreuid];


#if !defined(LEARNING)

#if defined(USE_STMICHAEL) 
    orig_init_module = sys_call_table[__NR_init_module]; 
#endif

    orig_delete_module = sys_call_table[__NR_delete_module];

#if defined(USE_STMICHAEL)
    sys_call_table[__NR_init_module] = sj_init_module;
#endif 

    orig_create_module = sys_call_table[__NR_create_module];
    sys_call_table[__NR_create_module] = sj_create_module;

#endif

    sys_call_table[__NR_setuid] = sj_setuid;
    sys_call_table[__NR_setreuid] = sj_setreuid;
    sys_call_table[__NR_fork] = sj_fork;
    sys_call_table[__NR_vfork] = sj_vfork;
    sys_call_table[__NR_clone] = sj_clone;
    sys_call_table[__NR_exit] = sj_exit;

#if defined(USE_STMICHAEL) && !defined(LEARNING) && defined(USE_CHECKSUM)
    syscall_reboot = sys_call_table[__NR_reboot];
    syscall_sync = sys_call_table[__NR_sync];
#endif

#if !defined(LEARNING) 

#if defined(FSCHECK) || defined(ROKMEM)
    sm_open = sys_call_table[__NR_open];
    sm_close = sys_call_table[__NR_close];
#endif
   

#if defined(USE_STMICHAEL)
   init_stmichael();
#endif


#endif // Of Learning Check


sjp_l_print("--=={ %s Loaded }\n", VERSION);

#if (LINUX_VERSION_CODE > KERNEL_VERSION(2,4,26)) 
 sjp_l_print("NOTICE: StJude has Not been Verified to Work on This Kernel.\n");
#endif


    return 0;
}

void
cleanup_module(void)
{
    /*
     * We should free our memory.. 
     */

  
    int             i;
   

sjp_l_print("--=={ Unloading %s }\n", VERSION);
#if defined(LEARNING) || ( defined(NOSEAL) && !defined(CLOAK) )

    sys_call_table[__NR_setuid] = orig_setuid;
    sys_call_table[__NR_setreuid] = orig_setreuid;
    sys_call_table[__NR_fork] = orig_fork;
    sys_call_table[__NR_vfork] = orig_vfork;
    sys_call_table[__NR_clone] = orig_clone;
    sys_call_table[__NR_exit] = orig_exit;
    sys_call_table[__NR_execve] = orig_do_execve;
     /* 
       We should wait until all calls are finished before ripping the 
       priv and memory out from underneath them, no? 
     */

#ifdef __SMP__
    write_lock(&sj_running);
#endif

    for (i = 0; i < SJ_PRIV_HASH; i++) {
	struct sj_priv *j,
	               *k;

	if (sj_priv_hash[i])
	    for (j = sj_priv_hash[i]; j;) {
		k = j;
		j = j->next;
		kfree(k);
	    }
    }
    
    for (i = 0; i < SJ_MEMORY_HASH; i++) {
	struct sj_argv_memory *j, *k;

	if (sj_argv_memory_hash[i])
	    for (j = sj_argv_memory_hash[i]; j;) {
		k = j;
		j = j->next;
		kfree(k);
	    }
    }



#ifdef __SMP__
    write_unlock(&sj_running);
#endif // __SMP__

#endif

sjp_l_print("--=={ %s Unloaded }\n", VERSION);
}


