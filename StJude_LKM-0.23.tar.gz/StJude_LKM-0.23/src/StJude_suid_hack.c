#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include "StJude_lkm.h"


extern SJ_PRIV *sj_priv_hash[SJ_PRIV_HASH];
extern SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];

extern SJ_RULEBASE sj_rulebase[];

/* This is a mite bit hackish way to handle suid programs. See below for more
   discussion. 
 */

void suid_hack(struct task_struct *p)
{
   struct sj_argv_memory *memory;

#ifdef DEBUG
   printk("(StJude) Entered Suid Hack\n");
#endif
        /* It has some vestiges of privilege, lets check
           if its in the hash. 
         */
                /* We do not have a priv record for this suid privileged.
                   process. This will occur, but only should occur when
                   a suid process is run. The privilege bits in the task
                   structure is set deep inside exec() without a syscall
                   (ie, the exec() call modifies the task_struc). This poses
                   a problem for us, since we do not know that a process
                   has been given privilege. What we will do here is extract
                   the argv's for the command from its memory, and create
                   a privl record after getting the proper restriction index.
                 */


		  memory = get_argv_memory(p);
                  if (memory) {
			    int r_index = 0;
                  
		/* Note, here we will need to get an index based on the parent. */

                           r_index =  get_restriction_index(p->p_pptr->pid,
						memory->argv);

                           create_priv_record(p->pid,r_index);
                    }
                    else  
                      create_priv_record(p->pid,0);
   			return;

}
