#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include <asm/segment.h>
#include "StJude_lkm.h"
#include "StJude_string_util.h"

#ifndef USE_OLD_EXECEVE
#include <linux/smp_lock.h>
#include "StJude_execve_util.h"
#endif

extern SJ_PRIV *sj_priv_hash[SJ_PRIV_HASH];
extern SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];

extern int sjexecve;

extern SJ_RULEBASE sj_rulebase[];

/*
 * This is it, what we have been waiting for, the grand show.
 *
 * First, check if we are a privileged process. If no, then let
 * them pass.
 *
 * If we are a privileged process, then we need to make sure that
 * what we want to execute is ok. We do this by calling check_priv_record.
 * If it is ok, then we will let them pass, but we have to do some
 * record keeping first.
 * 
 *    We need to modify the current privilege record to reflect the new
 *    command we are executing. We do this by changing the restriction
 *    list associated with the current process. The quickest way to do
 *    this is 
 *    modify_priv_record_restriction(pid,get_restriction_index(pid,argv)))
 *
 */

int
sj_do_execve (struct pt_regs regs)
{
  long sj_res;

  char * filename = (char *) regs.ebx;
  char ** argv = (char **) regs.ecx;

#if !defined(LEARNING)
  char ** envp = (char **) regs.edx;
#endif

  struct sj_argv_memory *memory, old_memory;
  struct sj_priv *priv, old_priv;
  int sj_i,sj_j,sj_argc;
  char sj_argv[MAX_KEY_ELEMENTS][BUFFSIZE];

#ifdef __SMP__
read_lock(&sj_running);
read_lock(&tasklist_lock);
#endif
#ifdef DEBUG
printk(" -----------------------------SYSCALL BY %d------------------------\n",current->pid);
#endif

#ifdef DEBUG
       printk("  (StJude) sj_execve: Entered sj_do_execve()\n");
#endif
 
   
  sj_argc = count(argv,MAX_KEY_ELEMENTS);
  sj_argc = (sj_argc == -E2BIG) ? MAX_KEY_ELEMENTS : sj_argc;
  
   for (sj_i = 0; sj_i < MAX_KEY_ELEMENTS; sj_i++)
	for (sj_j = 0; sj_j < BUFFSIZE; sj_j++)
	      sj_argv[sj_i][sj_j] = '\0';

   for (sj_i = 0; sj_i < BUFFSIZE && filename[sj_i] != '\0';
           sj_i++)
            sj_argv[0][sj_i] = filename[sj_i];


 
   sj_argv[0][sj_i] = '\0';

   
   for (sj_i = 1; sj_i < sj_argc; sj_i++)
     {
        for (sj_j = 0; sj_j < BUFFSIZE && argv[sj_i][sj_j] != '\0';
             sj_j++)
          {
              sj_argv[sj_i][sj_j] = argv[sj_i][sj_j];
          } 
          sj_argv[sj_i][sj_j] = '\0';
     } 

#ifdef __SMP__
write_lock(&priv_lock); 
write_lock(&argv_memory_lock); 
#endif

   memory = get_argv_memory(current);
   priv = get_priv_record(current->pid);


#if defined(CHECK_CAP)
   if ((!(current->uid && current->euid && current->suid) ) ||
		    ( current->cap_permitted & ( SJ_CAP_MASK ^ 0xFFFFFFFF))  ||
		    ( current->cap_effective & ( SJ_CAP_MASK ^ 0xFFFFFFFF)))
#else	
   if (!(current->uid && current->euid && current->suid) )
#endif
   {
      int r_index = 0;

    
      if (!priv) {
      suid_hack(current);
      } 

     

    if (!check_priv_record(current,sj_argv))
       {
          char *argv_string;
          char *parent_string;
          struct sj_argv_memory *p_memory;


          int i,j,k;
      

	  

          argv_string = kmalloc( sizeof(char) * ( ( (BUFFSIZE+2) * 
                                     MAX_KEY_ELEMENTS)), GFP_KERNEL);  
          parent_string = kmalloc( sizeof(char) * ( ( (BUFFSIZE+2) * 
                                     MAX_KEY_ELEMENTS)), GFP_KERNEL);  

          if ( ! ( argv_string && parent_string ) )
            { 
#ifdef LEARNING

		sjp_l_print("(STJUDE) LEARN-WARNING: CANT ALLOCATE MEMORY TO GENERATE LEARNING OUTPUT\n"); 	
                goto nomem_for_strings;

#else

		    sjp_l_print("(STJUDE) NOTICE: Process was PID %d. \n");
		    sjp_l_print("(STJUDE) NOTICE: NON-FATAL ERROR: UNABLE TO ALLOCATE MEMORY FOR FURTHER INFORMATION. RESPONSE CALLED.\n");
                    goto nomem_for_strings;
#endif
	  }

          for (i = 0; i < BUFFSIZE * MAX_KEY_ELEMENTS; i++)
		{ argv_string[i] = '\0'; parent_string[i] = '\0'; }


 
          k = 0; 
          for (i = 0; i < MAX_KEY_ELEMENTS && sj_argv[i][0] !='\0'; i++)
          {
              for (j = 0; j < BUFFSIZE && sj_argv[i][j] != '\0'; j++)
                 {
                    argv_string[k++] = sj_argv[i][j];
                    if (k >= ( BUFFSIZE * MAX_KEY_ELEMENTS)-2)
			       break;
                 }
                 
                     
                    if (k >= ( BUFFSIZE * MAX_KEY_ELEMENTS)-2)
			       break;
#ifdef LEARNING
		    argv_string[k++] = ':';
		    argv_string[k++] = ':';
#else

                    argv_string[k++] = ' ';
#endif
           }
#ifdef LEARNING
           argv_string[k-2] = '\0';
#else
           argv_string[k] = '\0';
#endif
    
           p_memory = get_argv_memory(current);
              

           if (p_memory && p_memory->argv)
           {

          k = 0; 
          for (i = 0; i < MAX_KEY_ELEMENTS && p_memory->argv[i][0] != '\0'; i++)
          {
              for (j = 0; j < BUFFSIZE && p_memory->argv[i][j] != '\0'; j++)
                 {
                    parent_string[k++] = p_memory->argv[i][j];
                    if (k >= ( BUFFSIZE * MAX_KEY_ELEMENTS)-2)
			       break;
                 }
                     
                    if (k >= ( BUFFSIZE * MAX_KEY_ELEMENTS)-2)
			       break; 
#ifdef LEARNING
		    parent_string[k++] = ':';
		    parent_string[k++] = ':';
#else  

                    parent_string[k++] = ' '; 
#endif 
           }

#ifdef LEARNING
           parent_string[k-2] = '\0';
#else
           parent_string[k] = '\0';
#endif

           }
           
		/* Apparently we don't have permission to do 
                   what we are wanting to do. First we bitch,
                   then we gripe. */

#ifdef SILENT
		goto silent_no_notice;
#endif

#ifdef LEARNING

		printk("(STJUDE) LEARN: [%s] executed [%s]\n",parent_string,argv_string); 	

#else

		sjp_l_print("(STJUDE) NOTICE: Execution Request Violates Privileges. Data Follows.\n");
		sjp_l_print("(STJUDE) NOTICE: UID: %d, EUID %d, Command Line: %s\n",current->uid, current->euid, argv_string);
		if (p_memory)
		    sjp_l_print("(STJUDE) NOTICE: Process was PID %d. Requester's Argv: %s\n",current->pid, parent_string);

#endif

#ifdef SILENT
silent_no_notice:
#endif
        /* Free the memory for our strings... */
        if (argv_string) kfree(argv_string);
        if (parent_string) kfree(parent_string);

nomem_for_strings:
#if defined (__SMP__) && ! defined (LEARNING)
         write_unlock(&argv_memory_lock);
         write_unlock(&priv_lock);
         read_unlock(&tasklist_lock); 
         read_unlock(&sj_running);
#endif

#ifndef LEARNING
	sj_do_response((char *) regs.ebx, (char **) regs.ecx, 
			(char **) regs.edx, &regs);
#endif
	return;
       }
#ifndef LEARNING
       else
#endif
       {

/* 
   If it wasn't illegal, and we are still privileged, then we need to 
   update our privilege record to the restrictions for our new process. 
   We will do this by figuring out the index to our new restriction, 
   destroying our privilege record and then creating a new privilege 
   record based on the index we have.
 */

            
            r_index =  get_restriction_index(current->pid, memory->argv);

            if (!priv)
               {  
                 priv = get_priv_record(current->pid);
               }
 
            old_priv.restriction = priv->restriction; 

            destroy_priv_record(current->pid); 
            create_priv_record(current->pid,r_index);

       }


		 

   } /* Of privileged Code */
   else
   {
     if (priv)
        {
	 /* 
          * A privilege record exists for a non-privileged process..
          * This can occur if a privileged binary execves a setuid-non-privileged
          * binary. By our logic, that process will not encounter any problems
          * until it has successfully executed another setuid root binary and
          * transitions back into a privileged state. In some circumstances it
          * may occur that the new setuid will not go thru the suid hack and
          * be bound by the restrictions of its distant predecessor. This may
          * be more restrictive or less restrictive, but either way its unintended
          * and thus bad.
	  *
          * This fixes it.
          */

           destroy_priv_record(current->pid);
           priv = NULL;

        } 
   }

    if (memory) 
       {
          int i,j;
          
          for (i = 0; i < MAX_KEY_ELEMENTS; i++)
		{
            for (j = 0; j < BUFFSIZE; j++)
	         {
 		       old_memory.argv[i][j]  = memory->argv[i][j]; 
		       memory->argv[i][j] = sj_argv[i][j]; 
             }
         }
		 memory->argv[i][BUFFSIZE-1] = '\0';
       }

#ifdef __SMP__
write_unlock(&argv_memory_lock);
write_unlock(&priv_lock);
read_unlock(&tasklist_lock);
read_unlock(&sj_running);
#endif
 
     {
        char * filename;

	lock_kernel();
        filename = getname((char *) regs.ebx);
        sj_res = PTR_ERR(filename);
        if (IS_ERR(filename))
             goto sj_execve_out;
	sj_res = sj_internal_execve(filename, (char **) regs.ecx, 
                                   (char **) regs.edx, &regs);
        if (sj_res == 0)
#if defined(PT_DTRACE)
                current->ptrace &= ~PT_DTRACE;
#else
		current->flags &= ~PF_DTRACE;
#endif
        putname(filename);
sj_execve_out:
	unlock_kernel();
    }


   if ( sj_res < 0 )
      {
           int i,j;
          
           for (i = 0; i < MAX_KEY_ELEMENTS; i++)
 		{
             for (j = 0; j < BUFFSIZE; j++)
 	         {
 		    memory->argv[i][j] = old_memory.argv[i][j];
                  }
 		 memory->argv[i][BUFFSIZE-1] = '\0';
        }

        if ( get_priv_record(current->pid)) 
        {
              destroy_priv_record(current->pid); 
              create_priv_record(current->pid,old_priv.restriction->r_index);
        }

 
      }  
    
  
  
  return (int) sj_res;
}


