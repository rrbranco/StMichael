#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */

#include <linux/modversions.h>
#include <linux/config.h>
#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,3,0)
#include <linux/dcache.h>
#endif
#include <linux/sched.h>
#include <linux/ptrace.h>
#include <linux/slab.h>
#include <linux/smp_lock.h>
#include <linux/mm.h>
#include <asm/uaccess.h>
#include <linux/file.h>
#include "StJude_lkm.h"
#include "StJude_string_util.h"
#include "StJude_execve_util.h"

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,3,0)
#define KERNEL_2_4
#endif

/* 
   Taken from fs/exec.c in the linux kernel tree, hence the GNU lisence 
   statement. 
 
   As with GNU, The use of this code is optional. If you do not want
   to use this GNU code, then define DONT_USE_INTERNAL_EXECVE

 */



/*
 * sys_execve() executes a new program.
 */
int sj_internal_execve (char * filename, char ** argv, char ** envp, struct pt_regs * p_regs)
{
	struct linux_binprm bprm;
#ifdef KERNEL_2_4
	struct file *file;
#else
        struct dentry *file;
#endif

	int retval;
	int i;


#ifdef KERNEL_2_4
	file = open_exec(filename);
#else
        file = open_namei(filename,0,0);
#endif

	retval = PTR_ERR(file);
	if (IS_ERR(file))
		return retval;

	bprm.p = PAGE_SIZE*MAX_ARG_PAGES-sizeof(void *);
#ifdef KERNEL_2_4
	sjp_l_memset(bprm.page, 0, MAX_ARG_PAGES*sizeof(bprm.page[0])); 
#else
        for (i=0 ; i<MAX_ARG_PAGES ; i++) /* clear page-table */
               bprm.page[i] = 0;
#endif

#ifdef KERNEL_2_4
	bprm.file = file;
#else
	bprm.dentry = file;
        bprm.java = 0;
#endif

	bprm.filename = filename;
	bprm.sh_bang = 0;
	bprm.loader = 0;
	bprm.exec = 0;

	if ((bprm.argc = count(argv, bprm.p / sizeof(void *))) < 0) {
#ifdef KERNEL_2_4
		allow_write_access(file);
		fput(file);
#else
		dput(file);
#endif
		return bprm.argc;
	}

	if ((bprm.envc = count(envp, bprm.p / sizeof(void *))) < 0) {
#ifdef KERNEL_2_4
		allow_write_access(file);
		fput(file);
#else
		dput(file);
#endif
		return bprm.envc;
	}

	retval = prepare_binprm(&bprm);
	if (retval < 0) 
		goto out; 

#ifdef KERNEL_2_4
	retval = copy_strings_kernel(1, &bprm.filename, &bprm);
	if (retval < 0) 
		goto out; 

	bprm.exec = bprm.p;
	retval = copy_strings(bprm.envc, envp, &bprm);
	if (retval < 0) 
		goto out; 

	retval = copy_strings(bprm.argc, argv, &bprm);
#else

        bprm.p = copy_strings(1, &bprm.filename, bprm.page, bprm.p, 2);
        bprm.exec = bprm.p;
        bprm.p = copy_strings(bprm.envc,envp,bprm.page,bprm.p,0);
        bprm.p = copy_strings(bprm.argc,argv,bprm.page,bprm.p,0);
        if ((long)bprm.p < 0)
		retval = (long)bprm.p;
#endif

	if (retval < 0) 
		goto out; 

	retval = search_binary_handler(&bprm,p_regs);

	if (retval >= 0)
		/* execve success */
		return retval;

out:
	/* Something went wrong, return the inode and free the argument pages*/
#ifdef KERNEL_2_4
	allow_write_access(bprm.file);
	if (bprm.file)
		fput(bprm.file);

	for (i = 0 ; i < MAX_ARG_PAGES ; i++) {
		struct page * page = bprm.page[i];
		if (page)
			__free_page(page);
	}
#else
	if (bprm.dentry)
		dput(bprm.dentry);

	for (i = 0 ; i < MAX_ARG_PAGES ; i++) 
		free_page(bprm.page[i]);	
#endif

	return retval;
}




