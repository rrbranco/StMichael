#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include "StJude_lkm.h"


extern SJ_PRIV *sj_priv_hash[SJ_PRIV_HASH];
extern SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];

extern SJ_RULEBASE sj_rulebase[];


/*
 * If we set the uid of the process to both non-root
 * ids then we can not transition back into root.
 * At this point we can then remove the privilege
 * entry from the stuff. 
 */

int
sj_setreuid (uid_t ruid, uid_t euid)
{
  int sj_setreuid_return;
  short privileged = 0;

#ifdef __SMP__
read_lock(&sj_running);
read_lock(&tasklist_lock);
#endif

#ifdef DEBUG
printk(" -----------------------------SYSCALL BY %d------------------------\n",current->pid);
#endif

#ifdef DEBUG
printk("(StJude) sj_setreuid: Entered setreuid()\n");
#endif
   
#if defined(CHECK_CAP)
   if ((!(current->uid && current->euid && current->suid) ) ||
		    ( current->cap_permitted & ( SJ_CAP_MASK ^ 0xFFFFFFFF))  ||
		    ( current->cap_effective & ( SJ_CAP_MASK ^ 0xFFFFFFFF)))
#else	
  if ( ! ( current->uid && current->euid && current->suid ) )
#endif
    { 
       struct sj_priv *priv;  

       privileged = 1;

#ifdef __SMP__
       write_lock(&priv_lock);
#endif

        priv = get_priv_record(current->pid);
  
        if(!priv) {
#ifdef __SMP__
           write_lock(&argv_memory_lock);
#endif
           suid_hack(current);  
#ifdef __SMP__
           write_unlock(&argv_memory_lock);
#endif
           }

#ifdef __SMP__
        write_unlock(&priv_lock);
#endif
    }
#ifdef __SMP__
read_unlock(&tasklist_lock);
#endif

  sj_setreuid_return = (*orig_setreuid) (ruid,euid);

#ifdef __SMP__
read_lock(&tasklist_lock);
#endif


  /* If it was privileged, but is not any more, then we should drip its record */

#if defined(CHECK_CAP)
   if ( privileged && ((!(current->uid && current->euid && current->suid) ) ||
		    ( current->cap_permitted & ( SJ_CAP_MASK ^ 0xFFFFFFFF))  ||
		    ( current->cap_effective & ( SJ_CAP_MASK ^ 0xFFFFFFFF))))
#else	
  if (privileged && ( current->uid && current->euid && current->suid ) )
#endif
    {

#ifdef __SMP__
        write_lock(&priv_lock);
#endif
         destroy_priv_record(current->pid);
#ifdef __SMP__
        write_unlock(&priv_lock);
#endif


    }

#ifdef __SMP__
read_unlock(&tasklist_lock);
read_unlock(&sj_running);
#endif

  return sj_setreuid_return;
}

