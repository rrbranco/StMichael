#define __KERNEL__

/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
#include <linux/modversions.h>
#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <sys/syscall.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include "StJude_lkm.h"


extern SJ_PRIV *sj_priv_hash[SJ_PRIV_HASH];
extern SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];

extern SJ_RULEBASE sj_rulebase[];

/* When a process exists, we shall delete the
   privilege entry. We need to know nothing about
   the process when it will no longer spawn
   processes. 
 */

int
sj_exit (int error)   /* DONE */
{
  int sj_exit_ret;

#ifdef __SMP__
read_lock(&sj_running);
read_lock(&tasklist_lock);
#endif

#ifdef DEBUG
printk(" -----------------------------SYSCALL BY %d------------------------\n",current->pid);
#endif

#ifdef DEBUG
  printk ("(StJude) sj_exit: Pid %d Exit.\n", current->pid);
#endif

#ifdef __SMP__
write_lock(&argv_memory_lock);
#endif

  destroy_argv_memory(current->pid);

#ifdef __SMP__
write_unlock(&argv_memory_lock);
#endif

#if defined(CHECK_CAP)
   if ((!(current->uid && current->euid && current->suid) ) ||
		    ( current->cap_permitted & ( SJ_CAP_MASK ^ 0xFFFFFFFF))  ||
		    ( current->cap_effective & ( SJ_CAP_MASK ^ 0xFFFFFFFF)))
#else	
  if (!(current->uid && current->euid && current->suid))
#endif
  {
        /* Its ok if we delete a record that doesn't exist here..
           If a suid program spawned and exit() was its first
           syscall it could happen. Thats all good. 
         */
#ifdef __SMP__
    write_lock(&priv_lock);
#endif
        destroy_priv_record(current->pid);
           
        
#ifdef __SMP__
    write_unlock(&priv_lock);
#endif
  }

#ifdef __SMP__
read_unlock(&tasklist_lock);
read_unlock(&sj_running);
#endif

#if defined(USE_STMICHAEL) && !defined(LEARNING)

#if defined(USE_CHECKSUM)
 sm_check_dependency_integrity();
#endif

 sm_check_sys_call_integrity();

#if defined(USE_CHECKSUM)
 sm_check_ktext_integrity();
#endif

#endif
  
  sj_exit_ret = (*orig_exit) (error);
  return sj_exit_ret;
}

void sm_exit_end ( void )
{ return; }

