


/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */

#ifdef __SMP__
#include <asm/spinlock.h>
#endif
#define SJ_PRIV_HASH 10
#define SJ_MEMORY_HASH 10
/* DOH! MAX_KEY_ELEMENTS must Equil MAX_RESTRICTIOS_ELEMENTS */
#define MAX_KEY_ELEMENTS 6
#define MAX_RESTRICTIONS_ELEMENTS 6
#define MAX_RESTRICTIONS 256
#define BUFFSIZE 256
#define NULL_ARGV { "","","","","","","" };
#include <linux/version.h>

#define VERSION "StJude_LKM 0.21"

/* Capabilities MASK */
/* Default is to MASK no vulnrabilities, */

#define SJ_CAP_MASK 0

/*
 * Alternatively, we could omit some capabilities by adding them to the mask.
 *
 * NOTE: By making these, that will prevent StJude from considering these
 *       capabilities in deciding what is privlaged.
 *
 * #define SJ_CAP_MASK (CAP_NET_BIND_SERVICE|CAP_SYS_NICE)
 *
 *    (capabilities & ( SJ_CAP_MASK ^ 0xFFFFFFFF ))
 */

/* We should verify we can run on this kernel... */

#if (!(((LINUX_VERSION_CODE > KERNEL_VERSION(2,2,0)) &&\
     LINUX_VERSION_CODE < KERNEL_VERSION(2,3,0)) ||\
    ((LINUX_VERSION_CODE > KERNEL_VERSION(2,4,0)) &&\
     LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))))
#error "Unable to Handle kernel versions outside the 2.2 and 2.4 series"
#endif


#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,2,11)) 
#error "Unable to Handle kernel versions lower then the 2.2.11"
#endif

#if (LINUX_VERSION_CODE > KERNEL_VERSION(2,4,26)) 
#warning "Saint Jude Has not Been Tested to Work on this kernel. Proceed with Caution."
#endif

/* Verified.. */

struct sj_priv
{
  int pid;
  struct sj_rulebase *restriction;
  struct sj_priv *next;
  struct sj_priv *prev;
};

struct sj_argv_memory
{
  int pid;
  char argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE];
  struct sj_argv_memory *next;
};


struct sj_rulebase
{
  int r_index;
  char *key[MAX_KEY_ELEMENTS+1];
  char *restrictions[MAX_RESTRICTIONS][MAX_RESTRICTIONS_ELEMENTS+1];
};


struct sj_override
{
  char key[BUFFSIZE];
  int  rule_index;
};

#ifdef __SMP__
rwlock_t argv_memory_lock;
rwlock_t priv_lock;
rwlock_t sj_running;
extern rwlock_t tasklist_lock;
#endif

typedef struct sj_rulebase SJ_RULEBASE;
typedef struct sj_priv SJ_PRIV;
typedef struct sj_argv_memory SJ_MEMORY;
typedef struct sj_override SJ_OVERRIDE;

#if !defined(HIDDEN_SYS_CALL_TABLE)
extern void *sys_call_table[];
#else
void **sys_call_table;
#endif


int (*orig_delete_module) (const char *name);
int (*orig_fork) (struct pt_regs regs);
int (*orig_exit) (int error);
int (*orig_vfork) (struct pt_regs regs);
int (*orig_clone) (struct pt_regs regs);
int (*orig_setuid) (uid_t uid);
int (*orig_setreuid) (uid_t ruid, uid_t euid);


int sj_fork (struct pt_regs regs);
int sj_vfork (struct pt_regs regs);
int sj_clone (struct pt_regs regs);
int sj_do_execve (struct pt_regs regs);
int sj_landmine (char *filename, char **argv, char **envp, struct pt_regs * regs);
int sj_delete_module (const char *name);
int sj_exit (int error);
int sj_setreuid (uid_t ruid, uid_t euid);
int sj_setuid (uid_t uid);

#if defined(USE_STMICHAEL) && !defined(LEARNING)

void init_stmichael( void );

asmlinkage long
sj_init_module (const char *name, struct module * mod_user);
asmlinkage long
(*orig_init_module) (const char *name, struct module * mod_user);
#endif

int (*orig_do_execve) (struct pt_regs regs);


void suid_hack (struct task_struct *p);

struct sj_priv *create_priv_record (pid_t pid, int restriction_index);
int destroy_priv_record (pid_t pid);
struct sj_priv *get_priv_record (pid_t pid);
int check_priv_record (struct task_struct *task, char argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE]);
int check_restriction (char
		       argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE],
		       char
		       *restrictions[MAX_RESTRICTIONS]
		       [MAX_RESTRICTIONS_ELEMENTS+1]);
int get_restriction_index (pid_t pid,
			   char argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE]);


struct sj_argv_memory *create_argv_memory (pid_t pid,
					   char argv[MAX_KEY_ELEMENTS +
						     1][BUFFSIZE]);
inline int destroy_argv_memory (pid_t pid);
inline struct sj_argv_memory *get_argv_memory (struct task_struct *task);

/* Prototype for the Response Functions */
inline int sj_do_response (char *filename, char **argv, char **envp, struct pt_regs *regs);



// STMichael LKM Specific Defines
//
//


#ifdef USE_CHECKSUM

#include "md5.h"
#include "sha1.h"

#define md5_sample_len 31
#define sha1_sample_len 31

struct fscheck_record {
  md5_byte_t file_operations_digest[16];
  md5_byte_t directory_operations_digest[16];
  md5_byte_t dentry_operations_digest[16];
  md5_byte_t super_operations_digest[16];
  struct file_operations * dir_operations;
  struct file_operations * file_operations;
  struct super_operations * super_operations;
  struct dentry_operations * dentry_operations;
};

//
// Primary init function for our data structures.
//
void init_stmichael( void );


// 
// Subbordinate setup functions to init_stmichael
//
int init_fscheck_record( struct fscheck_record * rec, char * filename , char * dirname);
void check_fscheck_record( struct fscheck_record * rec, char * filename, char * dirname );
int init_fscheck_records( void );
void check_fscheck_records( void );
  
 
typedef struct sm_syscall_record
{
  void *orig_call;
  md5_byte_t recorded_md5_digest[16];
  unsigned char recorded_sha1_digest[20];

}
SM_INTEGRITY_RECORD;

#else

typedef void *SM_INTEGRITY_RECORD;

#endif

#ifdef __SMP__
rwlock_t fscheck_lock;
#endif

// Some stuff we will need if we have to reboot the box.
//
long (*syscall_reboot) (int magic1, int magic2, unsigned int cmd, void * arg);
void (*syscall_sync) (void);

//
// The original exit system call for replacement.
//
int (*syscall_exit) (const int error);

//
// If we intend to make kmem read only, we need these.
//
#ifdef ROKMEM
ssize_t (*sj_write_kmem)(struct file * file, const char * buf, 
		  size_t count, loff_t *ppos);
void sm_kemem_ro ( void );
void sm_kemem_rw ( void );
#endif


//
// If we touch the filesystem, we will need to know these.
//
#if defined(FSCHECK) || defined(ROKMEM) || defined(REALLY_IMMUTABLE)
asmlinkage long (*sm_open)( const char * filename, int flags, int mode );
asmlinkage long (*sm_close)( int fd );
#endif

//
// Stuff for the non-removable immutable flag code.
//
#ifdef REALLY_IMMUTABLE
int init_really_immutable ( char * filename);

int sm_ext2_ioctl (struct inode * inode, struct file * filp, unsigned int cmd,
			unsigned long arg );
int (*orig_ext2_ioctl) ( struct inode * inode, struct file * filp,
			unsigned int cmd, unsigned long arg );
#endif

//
// Checksum specific functions.
//
#ifdef USE_CHECKSUM
void sm_integrity_check_checksum_init(SM_INTEGRITY_RECORD *record, void * target_function );
int sm_check_dependency_table( void );
int sm_check_sys_call_table();
int sm_check_specific_checksum(SM_INTEGRITY_RECORD *record);
void sm_check_dependency_integrity ( void );
void handle_catastrophic_kernel_compromise ( void );
#endif

void sm_integrity_check_init( void );
void sm_check_sys_call_integrity ( void  );
void sm_check_ktext_integrity ( void );

//
// How many dependencies do we have?
//
#if (LINUX_VERSION_CODE > KERNEL_VERSION(2,3,99))
#define NR_sm_dependencies 15
#else
#define NR_sm_dependencies 13
#endif


//
// Sets up the module list stuff.
//
int sm_init_module_list(void);


//
// Module list datastructure.
//
struct mli {
    struct module * module;
    char * name;
    int namelen;
    struct mli *next;
};

//
// Subordinate functions to the module initlization function.
//
int sm_add_module_list( void );
int  sm_check_module_list( void );
void sm_remove_module_list( const char * name );

asmlinkage unsigned long sj_create_module (const char *name, size_t size);
asmlinkage unsigned long (*orig_create_module) (const char *name, size_t size);


