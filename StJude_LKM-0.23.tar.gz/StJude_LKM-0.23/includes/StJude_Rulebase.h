


/* Saint Jude, Linux Kernel Module.
 * Verion: 0.22
 * 
 * October 27, 2002 - PumpCon Release 
 *
 *
 *    Copyright (C) 2001  Timothy Lalwess (lawless@wwjh.net)
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *
 * 
 */
/* If you use sudo, copy the "/bin/su" line, and replace "/bin/su"
   with the path to sudo. Increment the number to 3, and change the
   number in line 3 to 4. This should be done prior to going
   into learning mode to avoid a crap load of output when you
   try to administer the system....

   It would look something like the below, hey in fact.. Why don't
   ya just use the below one instead.. just make sure the
   path to sudo is right, ok?

   SJ_RULEBASE sj_rulebase[] = {
     {0, {NULL}, {{"NONE", NULL}, {NULL}}},
     {1, {NULL}, {{"ALL", NULL}, {NULL}}},
     {2, {"/bin/su", NULL}, {{"ALL", NULL}, {NULL}}},
     {3, {"/usr/bin/sudo", NULL}, {{"ALL", NULL}, {NULL}}},
     {4, {NULL}, {NULL}}
   };
 */


SJ_RULEBASE sj_rulebase[] = {
  {0, {NULL}, {{"NONE", NULL}, {NULL}}},
  {1, {NULL}, {{"ALL", NULL}, {NULL}}},
  {2, {"/bin/su", NULL}, {{"ALL", NULL}, {NULL}}},
  {3, {"/usr/bin/sudo", NULL}, {{"ALL", NULL}, {NULL}}},
  {4, {NULL}, {NULL}}
};


SJ_OVERRIDE sj_override[] = {
  {"/usr/sbin/sshd", 0 },
  {"/usr/sbin/atd", 0 },
  {"/usr/sbin/crond", 0 },
  {"/usr/sbin/rpc.nfsd", 0 },
  {"/usr/sbin/rpc.mountd", 0 },
  {"/sbin/rpc.statd", 0 },
  {"/sbin/syslogd", 0 },
  {"/usr/sbin/pppd", 0 },
  {"/sbin/portmap", 0 },
  { "", 0 } /* Terminal Value */
};
