#include <linux/sys.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <linux/smp.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <asm/errno.h>
#include "StMichael_lkm.h"
#include "StMichael_string_util.h"


int sm_exit (int error)   /* DONE */
{
  int sj_exit_ret=0;

#ifdef USE_CHECKSUM
 sm_check_dependency_integrity();
#endif

 sm_check_sys_call_integrity();
#if defined(USE_CHECKSUM) 
 sm_check_ktext_integrity ();
#endif

  //sj_exit_ret = (*orig_exit) (error);
  return sj_exit_ret;

}

void sm_exit_end ( void )
{ return; }

#ifdef CHECKSUM
md5_byte_t syscall_md5[16];
#endif

