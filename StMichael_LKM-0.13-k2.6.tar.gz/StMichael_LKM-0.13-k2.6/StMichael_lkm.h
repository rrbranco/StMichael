#include <linux/file.h>
#include <linux/fs.h>

#ifdef __SMP__
 #include <asm/spinlock.h>
#endif

#include <linux/version.h>

#define VERSION "StMichael 0.13"
#define BUFFSIZE 256

//
// Primary init function for our data structures.
//
 void init_stmichael( void );

#ifdef USE_CHECKSUM

 #include "md5.h"
 #include "sha1.h"
 #include "StMichael_Ref.h"

 #define md5_sample_len 31
 #define sha1_sample_len 31

 #ifdef FSCHECK

  struct fscheck_record {
   md5_byte_t file_operations_digest[16];
   md5_byte_t directory_operations_digest[16];
   md5_byte_t dentry_operations_digest[16];
   md5_byte_t super_operations_digest[16]; 
   struct file_operations * dir_operations;
   struct file_operations * file_operations;
   struct super_operations * super_operations;
   struct dentry_operations * dentry_operations;
  }; 

 #endif

// 
// Subbordinate setup functions to init_stmichael
//
 #if defined(FSCHECK)
  int init_fscheck_record( struct fscheck_record * rec, char * filename , char * dirname);
  void check_fscheck_record( struct fscheck_record * rec, char * filename, char * dirname );
  int init_fscheck_records( void );
  void check_fscheck_records( void );
 #endif
 
 
 typedef struct sm_syscall_record
 {
   void *orig_call;
   md5_byte_t recorded_md5_digest[16];
   unsigned char recorded_sha1_digest[20];
 }
 SM_INTEGRITY_RECORD;

#else
 typedef void *SM_INTEGRITY_RECORD;
#endif

#ifdef __SMP__
 rwlock_t sm_running;
 #ifdef FSCHECK
  rwlock_t fscheck_lock;
 #endif
#endif


//
// Checksum specific functions.
//
#ifdef USE_CHECKSUM
void sm_integrity_check_checksum_init(SM_INTEGRITY_RECORD *record, void * target_function );
int sm_check_dependency_table( void );
int sm_check_sys_call_table( void );
int sm_check_specific_checksum(SM_INTEGRITY_RECORD *record);
void sm_check_dependency_integrity ( void );
void handle_catastrophic_kernel_compromise ( void );
#endif

void sm_integrity_check_init( void );
void sm_check_sys_call_integrity ( void  );
void sm_check_ktext_integrity ( void );

//
// How many dependencies do we have?
//
#if (LINUX_VERSION_CODE > KERNEL_VERSION(2,3,99))
#define NR_sm_dependencies 15
#else
#define NR_sm_dependencies 13
#endif


//
// Sets up the module list stuff.
//
int sm_init_module_list(void);


//
// Module list datastructure.
//
struct mli {
    struct module * module;
    char * name;
    int namelen;
    struct mli *next;
};

//
// Subordinate functions to the module initlization function.
//
int sm_add_module_list( void );
int  sm_check_module_list( void );
void sm_remove_module_list( const char * name );

asmlinkage unsigned long sm_create_module (const char *name, size_t size);


//
// If we touch the filesystem, we will need to know these.
//
#if defined(FSCHECK) || defined(ROKMEM) || defined(REALLY_IMMUTABLE) || defined(ROMEM)
extern asmlinkage long (*sm_open)( const char * filename, int flags, int mode );
extern asmlinkage long (*sm_close)( int fd );
#endif

//
// Stuff for the non-removable immutable flag code.
//
#ifdef REALLY_IMMUTABLE
 int init_really_immutable ( char * filename);

 int sm_ext2_ioctl (struct inode * inode, struct file * filp, unsigned int cmd,
                        unsigned long arg );
extern int (*orig_ext2_ioctl) ( struct inode * inode, struct file * filp,
                        unsigned int cmd, unsigned long arg );
#endif

void sjp_l_bzero(void *ptr, int length);
