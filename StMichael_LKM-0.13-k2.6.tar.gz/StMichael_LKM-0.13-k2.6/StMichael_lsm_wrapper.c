#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/security.h>
#include "StMichael_lkm.h"


#ifdef LSM_HOOKS
int sm_register_security(const char *name, struct security_operations *ops)
{
	return 0;
}

int sm_unregister_security(const char *name, struct security_operations *ops)
{
	return 0;
}	

static struct security_operations sm_security_ops =
{
	.register_security =		sm_register_security,
	.unregister_security =		sm_unregister_security,
};

int sm_init_lsm(void)
{
	/* register ourselves with the security framework */
	if (register_security (&sm_security_ops)) 
	{
		printk(KERN_INFO "Failure registering StMichael module with the kernel (LSM Hooks)... trying with the existing LSM module...\n");

		if ( mod_reg_security(VERSION, &sm_security_ops)) 
		{
			printk(KERN_INFO "Failure registering StMichael module with the existing LSM module... selinux compiled into the kernel? Remove the LSM_HOOKS option into the StMichael compilation\n");
   			return -EINVAL;
		}
	}
	return 0;

}
#else
int sm_init_lsm(void)
{
	return 0;
}
#endif // LSM_HOOKS
