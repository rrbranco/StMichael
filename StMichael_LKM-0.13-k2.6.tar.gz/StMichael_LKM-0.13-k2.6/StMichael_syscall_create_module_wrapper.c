#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include "StMichael_lkm.h"

void sm_kmem_rw(void);
void sm_kmem_ro(void);
void sm_mem_rw(void);
void sm_mem_ro(void);

asmlinkage unsigned long
sm_create_module (const char *name, size_t size)
{
  int sm_res=0;

  /*
  * We can not lock the kernel across a wrapped systemcall
  */
#ifdef ROKMEM
  sm_kmem_rw();
#endif
#ifdef ROMEM
  sm_mem_rw();
#endif
//  sm_res = orig_create_module(name,size);
#ifdef ROKMEM
  sm_kmem_ro();
#endif
#ifdef ROMEM
  sm_mem_ro();
#endif

  //if (sm_res)
    //sm_add_module_list();

  return sm_res;

}

void sm_create_module_end ( void )
{ return;}



