#include <linux/timer.h>

#define SM_TIMEOUT		3600
#define MY_WORK_QUEUE_NAME	"StMichael_Work"
#define MY_WORK_QUEUE_NAME2	"StMichael_Work2"

void sm_timer_init(void);
void sm_timer_handler(void *);

// This should not be handeld by configure
//
//#warning If compile fails here read StMichael_timer.h.

// On some systems, particularly redhat boxes, this may cause
// A Problem -- Redhat has had it declared Elsewhere in their 
// 'Patched' Linux Distribution.
// If you encounter this compile time problem, Delete the next line.
//
//
//#if !defined(GOT_TIME)
//typedef struct timer_list timer_t;
//#endif

extern timer_t sm_timer;
