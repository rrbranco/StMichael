#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include "StMichael_lkm.h"
#include "StMichael_string_util.h"



void setup_dependency_table( void );

asmlinkage long
sm_init_module (const char *name, struct module * mod_user)
{
   int init_module_return=0;

//   init_module_return = (*orig_init_module)(name,mod_user);
   
  /* 
     Verify that the syscall table is the same. 
     If its changed then respond 

     We could probably make this a function in itself, but
     why spend the extra time making a call?

   */

   
#ifdef USE_CHECKSUM
   sm_check_dependency_integrity();
#endif

   sm_check_sys_call_integrity();

   sm_check_module_list();

#if defined(FSCHECK) && defined(USE_CHECKSUM)
#ifdef __SMP__
 write_lock(&fscheck_lock);
#endif
 check_fscheck_records();
#ifdef __SMP__
 write_unlock(&fscheck_lock);
#endif
#endif 

#if defined(USE_CHECKSUM)
  //sm_check_ktext_integrity();
#endif

  return init_module_return;

}
void sm_init_module_end ( void )
{ return; }

