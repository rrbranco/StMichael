#include <linux/sys.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <asm/segment.h>
#include <asm/unistd.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/smp_lock.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <asm/unistd.h>
#include <asm/current.h>
#include <asm/errno.h>
#include <asm/ptrace.h>
#include <asm/pgtable.h>
#include <linux/smp_lock.h>
#include <linux/init.h>

#include "StMichael_lkm.h"
#include "StMichael_string_util.h"
#include "StMichael_timer.h"

// preciso tirar o if (0) q esta lah embaixo


extern void *sj_s_text;
extern void *sj_e_text;

extern struct workqueue_struct *my_workqueue;
extern struct work_struct Task;

#ifdef USE_CHECKSUM
extern struct workqueue_struct *my_workqueue2;
extern struct work_struct Task2;
#endif

int die=0;


long *sys_call_table=(void *)0; // point to null

asmlinkage long (*orig_init_module) (const char *name,
                                     struct module * mod_user);
int (*orig_delete_module) (const char *name);
int (*orig_exit) (const int error);

//
// Some stuff we will need if we have to reboot the box.
//
long (*syscall_reboot) (int magic1, int magic2, unsigned int cmd, void * arg);
void (*syscall_sync) (void);

//
// The original exit system call for replacement.
//
int (*syscall_exit) (const int error);

//
// If we intend to make kmem read only, we need these.
//
#ifdef ROKMEM
 ssize_t (*sj_write_kmem)(struct file * file, const char * buf,
                  size_t count, loff_t *ppos);
#endif

#ifdef ROMEM
 ssize_t (*sj_write_mem)(struct file * file, const char * buf,
                  size_t count, loff_t *ppos);
#endif

//
// Systemcall replacements for init_module, delete_module, and exit()
//
asmlinkage long sm_init_module (const char *name, struct module *mod_user);
int sm_delete_module (const char *name);
int sm_exit (const int error);

int sm_init_lsm(void);

//
// Stuff for the non-removable immutable flag code.
//
#ifdef REALLY_IMMUTABLE
 int init_really_immutable ( char * filename);

 int sm_ext2_ioctl (struct inode * inode, struct file * filp, unsigned int cmd,
                        unsigned long arg );
 int (*orig_ext2_ioctl) ( struct inode * inode, struct file * filp,
                        unsigned int cmd, unsigned long arg );
#endif

asmlinkage unsigned long (*orig_create_module) (const char *name, size_t size);


//
// If we touch the filesystem, we will need to know these.
//
#if defined(FSCHECK) || defined(ROKMEM) || defined(REALLY_IMMUTABLE) || defined(ROMEM)
asmlinkage long (*sm_open)( const char * filename, int flags, int mode );
asmlinkage long (*sm_close)( int fd );
#endif


#define IS_IN_KERNEL_TEXT(addr)\
        (addr > (long)sj_s_text && addr < (long)sj_e_text) ? (1) : (0)

MODULE_LICENSE("GPL");

struct {
    unsigned short not_interesting;
    unsigned int base;
} __attribute__ ((packed)) idtr;

struct {
    unsigned short addr1;
    unsigned char not_interesting[4];
    unsigned short addr2;
} __attribute__ ((packed)) idt_entry;


/* Dumb implementation to find sys_call_table */
static unsigned long * find_sys_call_table(void)
{
    unsigned long *apontar;
    unsigned int local_sys_call_table;
    unsigned int system_call;
    asm ("sidt %0" : "=m" (idtr));

    system_call=idtr.base-1951524;
    local_sys_call_table=9376+idtr.base-(sizeof(idt_entry)*256*0x80*2);
    local_sys_call_table-= 0x41214; // kernel 2.6.16 
    apontar=(long *)(local_sys_call_table);
    return apontar;
}

    


static int __init stmichael_init(void)
{
//    extern struct module **eml;
//    extern struct module *iml;
//    struct module *m;
//    struct module **v;
//    struct module_symbol *s;
//    int i;

/*
    extern void * sm_start;
    extern void * sm_end;
*/
 
    lock_kernel();

    sys_call_table=find_sys_call_table();

    if ( ! sys_call_table )
	return -14; // Bad Address

#ifdef __SMP__
    rwlock_init(&sm_running);
#endif

    sjp_l_print("--=={Loading %s \n", VERSION);

/*
       // Now ya see me
       for ( m = THIS_MODULE; m->next != NULL; m = m->next );

       v = (struct module **) (++m);
#ifdef CLOAK
       *v = (THIS_MODULE)->next;
       // Now ya don't.
#endif
       eml = v;
       iml = NULL;

      sj_s_text = (void *) (PAGE_OFFSET|0x00100000);
      for ( m = *eml; m->next; m = m->next );
      for ( s = m->syms; s->name; s++ );
      sj_e_text = (void *) s;
*/


      // Although we should be the first to load, sometimes it
      // may be usefull to use us to look for unsophistocated 
      // LKM-RK's. This is an unexpensive test that uses what we 
      // allready have, so why not?
      //

	/* 
      for ( i = 0; i < NR_syscalls; i++ )
           if (!IS_IN_KERNEL_TEXT((long)*(sys_call_table+i)))
             {   
                 printk("(STMICHAEL) Possible LKM Rootkit Detected during Load.\n");
                 printk("(STMICHAEL) Unable to Perform Recovery. Load of StMichael Aborted.\n");
                 printk("(STMICHAEL) If this message is being erronously generated, Read the NOTE in StMichael_lkm.c\n");
              

// NOTE NOTE NOTE NOTE NOTE NOTE NOTE
// If you are recieving a notice that the kernel is comprimised on
// Load AND you have validated that there is no Rootkid present, but
// that the cause of the error message is caused by a legitimate module.
// Then uncomment the following line:
//         if(0)

                 return -1;

// Also, contact me (lawless@wwjh.net) with specifics on your configuration
// So that I may account for it, and test it in simulation.
// Thanks.

             }
	*/
	
    orig_init_module = (void *) (*(sys_call_table + __NR_init_module)); 
    orig_delete_module = (void *) (*(sys_call_table + __NR_delete_module));
    orig_exit = (void *) (*(sys_call_table + __NR_exit));
    orig_create_module = (void *) (*(sys_call_table + __NR_create_module));

#if defined(FSCHECK) || defined(ROKMEM) || defined(REALLY_IMMUTABLE)
    sm_open = (void *) (*(sys_call_table + __NR_open)); 
    sm_close = (void *) (*(sys_call_table + __NR_close)); 
#endif

    syscall_reboot = (void *) (*(sys_call_table + __NR_reboot));
    syscall_sync = (void *) (*(sys_call_table + __NR_sync));

    *((long *)sys_call_table + __NR_init_module  ) = (long) sm_init_module;
    *((long *)sys_call_table + __NR_delete_module) = (long) sm_delete_module; 
    *((long *)sys_call_table + __NR_create_module) = (long) sm_create_module; 
    // *((long *)sys_call_table + __NR_exit) = (long) sm_exit; // problems including in the 2.4 series



/*
    if (sm_init_module_list())
         return -1;
*/

    init_stmichael();
    sm_init_lsm();


    sjp_l_print("--=={%s Successfully Loaded\n", VERSION);

    /*

    {
      // This function will self destruct in 5 miliseconds...

      unsigned long filler = 0x00000000;
      unsigned long *p;

      for ( p = (unsigned long *) &m;
            p < (unsigned long *) &filler;
            p++)
		*p = filler;
    }

    sjp_l_bzero((void *) (THIS_MODULE), sizeof(struct module));
    */

    unlock_kernel();
    return 0;

}

static void __exit stmichael_exit(void)
{
  // We can't unload, not now. not no more.
  return;

}

module_init(stmichael_init);
module_exit(stmichael_exit);
