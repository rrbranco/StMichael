#define __KERNEL__

/* Saint Jude, Solaris Kernel Module.  
 * Verions: 0.10
 *
 * May 13, 2002 - Happy Mothers Day Mom.
 *
 * Copyright: Tim Lawless <lawless@wwjh.net>, All rights Reserved.
 * 
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 * 
 *    Note should be taken that this is considered experimental software.
 *    It is not intended for any purpose other then to be pretty to look
 *    at. Do not feed this source code to your pets, and keep it out of
 *    the hands of kids. Do not expose this code to direct microwave 
 *    radiation. Prolonged exposure to kernel module source code 
 *    can cause irreversable harm.
 *    
 *    You have been warned.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *    Do not modify this Comment.
 */

#include <sys/types.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/proc.h>
#include "StJude_skm.h"

SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];
extern krwlock_t sj_data_rwlock;


inline struct sj_argv_memory *
create_argv_memory (pid_t pid, char argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE])
{
  struct sj_argv_memory *memory;
  register int i, j;


  // Just a sanity check. The Garbage collector should have collected
  // any stray processes information before the pid could have been
  // recycled. However, this is an assumption. Those can be bad.
  //
  // Before doing anything, check to make shure that get_argv_memory
  // returns nothing.

 
  memory = sj_argv_memory_hash[pid % SJ_MEMORY_HASH];

  while (memory != NULL)
    {

      if (memory->pid == pid)
	break;

      memory = memory->next;

    }

   // If we have a memory, then destroy it, and any possible 
   // priv record. 

   if ( memory != NULL) 
        {
          cmn_err(CE_NOTE,"It looks like a memory allready exists.\n");
          destroy_argv_memory(pid);
          destroy_priv_record(pid);
          memory = NULL;
        }

   // Ok, things should be sane from here on out. Grab some memory,
   // construct our memory, then put it where it belongs.
     
  memory = kmem_alloc (sizeof (*memory), KM_SLEEP);
  for (i = 0; i < MAX_KEY_ELEMENTS; i++)
	bzero(memory->argv[i],BUFFSIZE);

  if (memory)
    {
      memory->pid = pid;
      for (i = 0; i < MAX_KEY_ELEMENTS + 1; i++)
	for (j = 0; j < BUFFSIZE; j++)
	  memory->argv[i][j] = argv[i][j];
      memory->next = sj_argv_memory_hash[memory->pid % SJ_MEMORY_HASH];
      sj_argv_memory_hash[memory->pid % SJ_MEMORY_HASH] = memory;
      return memory;
    }
  else
    {
      cmn_err (CE_WARN, "<1>(STJUDE) Unable to allocate memory structure\n");
      return NULL;
    }

}

/*
 * 
 * Get a priv record based on its pid.  (DUH!)
 * 
 */


inline struct sj_argv_memory *
get_argv_memory (proc_t * p_process)
{
  struct sj_argv_memory *memory;
  pid_t pid;


  pid = p_process->p_pidp->pid_id;

  for (memory = sj_argv_memory_hash[pid % SJ_MEMORY_HASH];
       memory != NULL;
       memory = memory->next)
	      if (memory->pid == pid)
			break;


  return memory;
}

inline int
destroy_argv_memory (pid_t pid)
{
  struct sj_argv_memory *memory;
  struct sj_argv_memory *prev;

  prev = NULL;
  memory = sj_argv_memory_hash[pid % SJ_MEMORY_HASH];

  while (memory != NULL)
    {

      if (memory->pid == pid)
	break;

      prev = memory;
      memory = memory->next;

    }


  if (memory != NULL)
    {
      if (prev != NULL)
	prev->next = memory->next;
      else
	sj_argv_memory_hash[pid % SJ_PRIV_HASH] = memory->next;

      kmem_free (memory, sizeof (SJ_MEMORY));

    }
  else
    {
      return 0;
    }				/*
				 * * Tried to delete a record that doesn't
				 * exit 
				 */

  return 1;
}

// 
// When a vfork is encountered, we do not get the chance to create
// all the data structures needed. This can cause false positive
// readings when an execution occurs. To get around this, the solutions
// is to perform a test for the memory for the current process at the
// beginning of each of the significant functions. If no memory is
// found, then we need to handle the vfork condition that has occured.
//

void sj_do_vfork_hack ( proc_t * p_process );

// Can we do a recursive vfork condition check, locking the system
// till we can recurse back to find the original process?
void sj_check_fork_condition ( proc_t * p_process, int flag, int tag)
{

    struct sj_argv_memory *memory;
    krw_t lock_type;
    char lock_held = FALSE;
  

    // All this is futile if the parent doesn't have sync.

if (!rw_lock_held(&sj_data_rwlock))
   {
	rw_enter(&sj_data_rwlock,RW_WRITER);
   }
else {
        lock_held = TRUE;

	if (rw_write_held(&sj_data_rwlock))
		lock_type = RW_WRITER;
	else {
		rw_exit(&sj_data_rwlock);
		rw_enter(&sj_data_rwlock,RW_WRITER);
                lock_type = RW_READER;

		}
      }
	
if (!rw_lock_held(&sj_data_rwlock) && lock_held)
	cmn_err(CE_NOTE,"NOTE: It seems our lock dropped on us at STAGE 1 \n"); 

    sj_check_fork_sync(p_process->p_parent, 1 + tag );

if (!rw_lock_held(&sj_data_rwlock) && lock_held)
	cmn_err(CE_NOTE,"NOTE: It seems our lock dropped on us at STAGE 2 \n"); 
    memory = get_argv_memory(p_process);

if (!rw_lock_held(&sj_data_rwlock) && lock_held)
	cmn_err(CE_NOTE,"NOTE: It seems our lock dropped on us at STAGE 3 \n"); 

    if (!memory)
       {
         sj_do_vfork_hack(p_process); 
if (!rw_lock_held(&sj_data_rwlock) && lock_held)
	cmn_err(CE_NOTE,"NOTE: It seems our lock dropped on us at STAGE 4 \n"); 
         if (flag)
            sj_create_fork_sync(p_process->p_pidp->pid_id);
if (!rw_lock_held(&sj_data_rwlock) && lock_held)
	cmn_err(CE_NOTE,"NOTE: It seems our lock dropped on us at STAGE 5 \n"); 
       }

if (!lock_held)
	rw_exit(&sj_data_rwlock);
else 
	if (!rw_lock_held(&sj_data_rwlock) && lock_held)
	{	
		cmn_err(CE_NOTE,"NOTE: It seems our lock dropped on us . \n");
        }
	else
	{
		if (lock_type == RW_READER && (rw_write_held(&sj_data_rwlock)) )
			rw_downgrade(&sj_data_rwlock);
	}
    
   return;
}

void sj_do_vfork_hack ( proc_t * p_process )
{

    struct sj_argv_memory *parent_memory;
   
#ifdef DEBUG
       cmn_err(CE_NOTE,"(%d) Entered sj_do_vfork_hack.\n",
		p_process->p_pidp->pid_id);
#endif


#ifdef DEBUG
       cmn_err(CE_NOTE,"(%d) Checking For fork_sync for My Parent is %d\n",
		p_process->p_pidp->pid_id,p_process->p_parent->p_pidp->pid_id);
#endif

// When calling fork sync check, we can not hold any locks.


#ifdef DEBUG
       cmn_err(CE_NOTE,"(%d) sj_do_vfork_hack: Doing Memory. My Parent is %d\n",
		p_process->p_pidp->pid_id,p_process->p_parent->p_pidp->pid_id);
#endif

    parent_memory  = get_argv_memory(p_process->p_parent);


    if (parent_memory)
        {
           struct sj_argv_memory *memory;
           memory = create_argv_memory(p_process->p_pidp->pid_id,
			parent_memory->argv );
#ifdef DEBUG
           if (!memory)
                 cmn_err(CE_WARN,"(StJude) sj_fork: Something bad happened, I can't remember argv's\n");
#endif
	}
	else
	{

	   cmn_err(CE_WARN,"(StJude) vfork_hack: Something bad happened, I can't find my parent's (%d) memory.\n", p_process->p_ppid);
           
	}
    // Now, handle privlage. If this process is privlaged and its
    //  parent was privlaged, then we create it a privlage record
    //  based on its parent. If this process is privlaged and its
    //  parent is not privlaged, then we will do the association with 0.
    // 


    if (!(p_process->p_cred->cr_uid && p_process->p_cred->cr_ruid &&
	  p_process->p_cred->cr_suid ))
    {

        struct sj_priv *priv = NULL;
#ifdef DEBUG
       cmn_err(CE_NOTE,"(%d) sj_do_vfork_hack: Doing Priv\n",
		p_process->p_pidp->pid_id);
#endif


        priv = get_priv_record(p_process->p_ppid,0,RW_WRITER);

#ifdef DEBUG
       cmn_err(CE_NOTE,"(%d) sj_do_vfork_hack: Got Priv, Creaitng New Priv\n",
		p_process->p_pidp->pid_id);
#endif
       
        if (priv) 
            create_priv_record(p_process->p_pidp->pid_id, priv->restriction->r_index);
        else
            create_priv_record(p_process->p_pidp->pid_id, 0);
#ifdef DEBUG
       cmn_err(CE_NOTE,"(%d) sj_do_vfork_hack: Priv Created.\n",
		p_process->p_pidp->pid_id);
#endif

    }

#ifdef DEBUG
       cmn_err(CE_NOTE,"(%d) sj_do_vfork_hack: Done\n",
		p_process->p_pidp->pid_id);
#endif

  return;
}
