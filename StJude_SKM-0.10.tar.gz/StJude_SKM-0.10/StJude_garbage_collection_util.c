#define __KERNEL__

/* Saint Jude, Solaris Kernel Module.  
 * Verions: 0.10
 *
 * May 13, 2002 - Happy Mothers Day Mom.
 *
 * Copyright: Tim Lawless <lawless@wwjh.net>, All rights Reserved.
 * 
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 * 
 *    Note should be taken that this is considered experimental software.
 *    It is not intended for any purpose other then to be pretty to look
 *    at. Do not feed this source code to your pets, and keep it out of
 *    the hands of kids. Do not expose this code to direct microwave 
 *    radiation. Prolonged exposure to kernel module source code 
 *    can cause irreversable harm.
 *    
 *    You have been warned.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *    Do not modify this Comment.
 */

#include <sys/types.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/proc.h>
#include "StJude_skm.h"

extern krwlock_t sj_data_rwlock;
extern kmutex_t sj_runlock;

extern SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];

time_t last_collection = 0;
time_t collection_delay = 5;

int pid_defunct ( pid_t pid )
{

   register proc_t *p;

    
   if (!pid)       // Its not a pointer, but pid 0 is special, and
      return 0;    // we dont' mess with it. ;)

  //mutex_enter(&pidlock);

  p = proc_sched;

  do {
     if (p->p_pidp->pid_id == pid)
	{ 
   //       mutex_exit(&pidlock);
          return 0;
        }
     p = p->p_prev; 
   } while ( p &&  p != proc_sched );    

  //mutex_exit(&pidlock);
  return 1;

}

// sj_garbage_collection:
//
// Function to handle the identification of memory structures
// that are no longer needed.
//
// Instead of fighting with the syncronication between kernel
// threads and exit(), we implement a generic garbage collection
// function to identify and free memory allocated for now defunct 
// processes.
//


void sj_garbage_collection ( void )
{

  register int hash_count;
  time_t now;

  // We have a memory structure for every running process.
  // If we can walk through memory and not find the associated
  // process, then we need to eliminate memory associated with
  // that process (keyed by pid).

 
  now = ddi_get_time();
  if ((now - last_collection > collection_delay) 
		&& last_collection < now)
	return;

  last_collection = now;

  for ( hash_count = 0; hash_count < SJ_MEMORY_HASH; hash_count++ )
    {

      register struct sj_argv_memory *m;

restart_hash_entry:
      for ( m = sj_argv_memory_hash[hash_count]; m != NULL; m = m->next ) 
          if ( pid_defunct(m->pid) )
           {
              destroy_priv_record(m->pid);
              sj_destroy_fork_sync(m->pid);
              destroy_argv_memory(m->pid);
               // Since we modified the hash we are using, its
               // prolly best to restart from a known good state. ;)

              goto restart_hash_entry; 

             }
    }   

   return;
}
