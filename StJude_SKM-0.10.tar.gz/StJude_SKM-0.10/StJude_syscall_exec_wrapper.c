
/* Saint Jude, Solaris Kernel Module.  
 * Verions: 0.10
 *
 * May 13, 2002 - Happy Mothers Day Mom.
 *
 * Copyright: Tim Lawless <lawless@wwjh.net>, All rights Reserved.
 * 
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 * 
 *    Note should be taken that this is considered experimental software.
 *    It is not intended for any purpose other then to be pretty to look
 *    at. Do not feed this source code to your pets, and keep it out of
 *    the hands of kids. Do not expose this code to direct microwave 
 *    radiation. Prolonged exposure to kernel module source code 
 *    can cause irreversable harm.
 *    
 *    You have been warned.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *    Do not modify this Comment.
 */

#include <sys/types.h>
#include <sys/systm.h>
#include <sys/proc.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/thread.h>
#include <sys/copyops.h>
#include <sys/exec.h>
#include "StJude_skm.h"

extern krwlock_t sj_data_rwlock;
extern kmutex_t sj_runlock;
extern ksema_t sj_sema;
extern sj_fork_sync_delay;

char * sj_stk_getptr(char *src);

/*
 * This is it, what we have been wating for, the grand show.
 *
 * First, check if we are a privlaged process. If no, then let
 * them pass.
 *
 * If we are a privlaged process, then we need to make shure that
 * what we want to execute is ok. We do this by calling check_priv_record.
 * If it is ok, then we will let them pass, but we have to do some
 * record keeping first.
 * 
 *    We need to modify the current privlage record to reflect the new
 *    command we are executing. We do this by changing the restriction
 *    list associated with the current process. The quickest way to do
 *    this is 
 *    modify_priv_record_restriction(pid,get_updated_restriction_index(pid,argv)))
 *
 */


int
sj_exec (char *_filename, char *_argv[])
{
  long sj_res;

  struct sj_argv_memory *memory = NULL;
  struct sj_priv *priv = NULL;
  struct sj_priv *testpriv = NULL;
  int sj_argc, sj_j;
  pid_t pid;
  int privlaged = 0;
  char sj_argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE];
  char test_buf[BUFFSIZE]; 
  char *argvp;
  char *sj_argv_ptr; 
  char _argv_char[1];
  char *ptr = NULL;
  char *test = NULL;
  k_sigset_t saved_mask;
  proc_t *sj_curproc = ttoproc(curthread);
  proc_t *sj_curproc_old; 
  int i; int dbc;

  if (curthread == sj_curproc->p_agenttp)
         return (ENOTSUP);
  if (curthread == sj_curproc->p_aslwptp)
         return (EACCES);
 
  if (_filename == NULL || _argv == NULL)
      return -1;

dbc = 0;
sj_pre_exec:
  mutex_enter(&sj_curproc->p_lock);
  rw_enter (&sj_data_rwlock, RW_WRITER);
  if (!sema_tryp(&sj_sema))
        {
          rw_exit(&sj_data_rwlock);
          mutex_exit(&sj_curproc->p_lock);
          if (dbc > 21)
		cmn_err(CE_NOTE,"CAUGHT IN LOOP. STATION B\n");
          SJ_DO_DELAY();
          dbc++;
          goto sj_pre_exec;
        }
  else
        {
          while(sema_tryp(&sj_sema));
          sema_v(&sj_sema);
          mutex_exit(&sj_curproc->p_lock);
        }


  sj_check_fork_condition(sj_curproc, CREATE_SYNC, 1000);
  sj_check_fork_sync (sj_curproc,99);
  pid = sj_curproc->p_pidp->pid_id;





#ifdef DEBUG
  cmn_err (CE_NOTE,
	   " (EXEC) -----SYSCALL BY %d-----",
	   (int) sj_curproc->p_pidp->pid_id);
#endif

#ifdef DEBUG
  cmn_err (CE_NOTE, "  (StJude) sj_exec: Entered sj_do_exec()");
#endif


  for (sj_argc = 0; sj_argc < MAX_KEY_ELEMENTS + 1; sj_argc++)
    bzero(sj_argv[sj_argc++],BUFFSIZE);

  copyinstr (_filename, sj_argv[0], BUFFSIZE, 0);


// -- Start Get Args.

   for (sj_argc = 1; sj_argc < MAX_KEY_ELEMENTS; sj_argc++ )
   {

     // This looks odd, but its perfectly normal. Trust me.
     // When the compiler compiles this for the v9 arch, char *
     // is a 64bit pointer (size = 8). However, if a process in the 
     // compatable32bit mode runs execve on a v9 system, we have a 
     // 32bit pointer in the stack (size = 4). Hence the 
     // ((sizeof(char *) / 2) -- ie IF we are compiled for 64bit mode,
     // but this is a 32 bit process (and hence the pointer on the stack
     // is a 32bit pointer) we need a pointer of size 4, not 8.
     // AFTER we get the data in the kenrel space, everything is normal.

     if (sj_curproc->p_model == DATAMODEL_NATIVE)
      	 argvp = sj_stk_getptr((char *)(_argv) + 
			((sizeof(char *)) * sj_argc));
     else
      	 argvp = sj_stk_getptr((char *)(_argv) 
		+ ((sizeof(char *) / 2) * sj_argc));

       if (!argvp || (((int) argvp) < 0))
          goto sj_exec_end_of_args;
       copyinstr((char *) argvp,sj_argv[sj_argc], BUFFSIZE, 0);
       if (sj_argv[sj_argc][0] == '\0')
           {
sj_exec_end_of_args:
              break;
           }
    }
   
// -- End of Get Args


  if (!(sj_curproc->p_cred->cr_uid &&
	sj_curproc->p_cred->cr_ruid && sj_curproc->p_cred->cr_suid))
    {
      int r_index = 0;
  
      priv = get_priv_record (sj_curproc->p_pidp->pid_id,0,RW_READER);

      if (!priv)
	{

#ifdef DEBUG
	  cmn_err (CE_WARN,
		   "(STJUDE) (exec) get_priv_record returned NULL for query on a prived process (%d).",
		   sj_curproc->p_pidp->pid_id);
#endif
          rw_exit (&sj_data_rwlock);
	  return -1;
	}


      privlaged = 1;

     if (!check_priv_record(sj_curproc,sj_argv))
       {
          char *argv_string;
          char *parent_string;
          struct sj_argv_memory *p_memory;

          int i,j,k;
      

          argv_string = kmem_alloc( sizeof(char) * ( ( (BUFFSIZE+2) * 
                                     MAX_KEY_ELEMENTS)), KM_SLEEP);  
          parent_string = kmem_alloc( sizeof(char) * ( ( (BUFFSIZE+2) * 
                                     MAX_KEY_ELEMENTS)), KM_SLEEP);  

	  bzero(argv_string, (( BUFFSIZE + 2 ) * MAX_KEY_ELEMENTS));
	  bzero(parent_string, (( BUFFSIZE + 2 ) * MAX_KEY_ELEMENTS));

          if ( ! ( argv_string && parent_string ) )
            { 
#ifdef LEARNING

		cmn_err(CE_NOTE,"(STJUDE) LEARN-WARNING: CANT ALLOCATE MEMORY TO GENERATE LEARNING OUTPUT"); 	
                goto sj_exec_nomem_for_strings;

#else

		    cmn_err(CE_NOTE,"(STJUDE) NOTICE: Process was PID %d. ");
		    cmn_err(CE_NOTE,"(STJUDE) NOTICE: NON-FATIL ERROR: UNABLE TO ALLOCATE MEMORY FOR FURTHER INFORMATION. RESPONSE CALLED.");
                    goto sj_exec_nomem_for_strings;
#endif
	  }  // Close of memory allocation test.

          for (i = 0; i < BUFFSIZE * MAX_KEY_ELEMENTS; i++)
		{ argv_string[i] = '\0'; parent_string[i] = '\0'; }



          k = 0; 
          for (i = 0; i < sj_argc && sj_argv[i][0] !='\0'; i++)
          {
              for (j = 0; j < BUFFSIZE && sj_argv[i][j] != '\0'; j++)
                 {
                    argv_string[k++] = sj_argv[i][j];
                    if (k >= ( BUFFSIZE * MAX_KEY_ELEMENTS)-2)
			       break;
                 }
                 
                     
                    if (k >= ( BUFFSIZE * MAX_KEY_ELEMENTS)-2)
			       break;
#ifdef LEARNING
		    argv_string[k++] = ':';
		    argv_string[k++] = ':';
#else

                    argv_string[k++] = ' ';
#endif
           } // Close of Outer loop for sj_argv for loop.

#ifdef LEARNING
           argv_string[k-2] = '\0';
#else
           argv_string[k] = '\0';
#endif
    
           p_memory = get_argv_memory(sj_curproc);
           if (p_memory)
           {

          k = 0; 
          if (p_memory->argv[0][0] == '\0')
                       cmn_err(CE_NOTE,"Memory Argv is Null!\n");

          for (i = 0; i < MAX_KEY_ELEMENTS && p_memory->argv[i][0] != '\0'; i++)
          {
              for (j = 0; j < BUFFSIZE && p_memory->argv[i][j] != '\0'; j++)
                 {
                    parent_string[k++] = p_memory->argv[i][j];
                    if (k >= ( BUFFSIZE * MAX_KEY_ELEMENTS)-2)
			       break;
                 }
                     
                    if (k >= ( BUFFSIZE * MAX_KEY_ELEMENTS)-2)
			       break; 
#ifdef LEARNING
		    parent_string[k++] = ':';
		    parent_string[k++] = ':';
#else  

                    parent_string[k++] = ' '; 
#endif 
           }  // Close of outer argv walk loop.

#ifdef LEARNING
           parent_string[k-2] = '\0';
#else
           parent_string[k] = '\0';
#endif

           }  // Close of if p_memory
           
#ifdef SILENT
		goto sj_exec_silent_no_notice;
#endif

#ifdef LEARNING

	cmn_err(CE_NOTE,"(STJUDE) LEARN: [%s] executed [%s]",parent_string,argv_string); 	
                   
#else
#if !defined(SILENT)
		cmn_err(CE_NOTE,"(STJUDE) NOTICE: Execution Request Violates Privlages. Data Follows.");
		cmn_err(CE_NOTE,"(STJUDE) NOTICE: UID: %d, EUID %d, Command Line: %s",sj_curproc->p_cred->cr_ruid, sj_curproc->p_cred->cr_uid, argv_string);
		if (p_memory)
		    cmn_err(CE_NOTE,"(STJUDE) NOTICE: Process was PID %d. Requestor's Argv: %s",sj_curproc->p_pidp->pid_id, parent_string);

#endif
#endif

#ifdef SILENT
sj_exec_silent_no_notice:
#endif
        if (argv_string) 
		kmem_free(argv_string,
                ( sizeof(char) * ( ( (BUFFSIZE+2) * MAX_KEY_ELEMENTS))));  
        if (parent_string) 
		kmem_free(parent_string,
                ( sizeof(char) * ( ( (BUFFSIZE+2) * MAX_KEY_ELEMENTS))));  

sj_exec_nomem_for_strings: ;;

#ifndef LEARNING
        rw_exit (&sj_data_rwlock);
	return sj_do_response(_filename, _argv, NULL);
#endif
         
       
       } // Close of not acceptable execution

    }  // Close of IF_PRIVLAGED 

  // 1. Destroy the Fork Sync.
  // 2. Call the old Execve.

  //    sj_check_fork_sync(sj_curproc->p_pidp->pid_id,201);

#ifdef DEBUG
  cmn_err(CE_NOTE,"(EXEC) About to Drop the Semiphore.\n");
#endif

  while(sema_tryp(&sj_sema)); // Drop the Semaphore to Zero.
#ifdef DEBUG
  cmn_err(CE_NOTE,"(EXEC) Dropped the Semiphore.\n");
#endif


  sj_destroy_fork_sync(pid);
  rw_exit (&sj_data_rwlock);
#ifdef DEBUG
  cmn_err(CE_NOTE,"(EXEC) Calling Execve.\n");
#endif

#if defined(__SYSCALL32_IMPL)
  if (sj_curproc->p_mode == DATAMODEL_NATIVE)
      sj_res  = (*orig32_exec)(_filename,_argv);
  else
#endif
  sj_res = (*orig_exec) (_filename, _argv);


#ifdef DEBUG
  cmn_err(CE_NOTE,"(EXEC) Execve Returned. Getting Locks\n");
#endif

  rw_enter(&sj_data_rwlock,RW_WRITER);
#ifdef DEBUG
  cmn_err(CE_NOTE,"(EXEC) Locks Gotten, Raising Semaphore\n");
#endif

  if (!sema_tryp(&sj_sema))
  	sema_v(&sj_sema);
  else
	cmn_err(CE_NOTE,"Someone or Something Upped our Semaphore.\n");

#ifdef DEBUG
  cmn_err(CE_NOTE,"(EXEC) Rose Semaphore\n");
#endif

  sj_curproc_old = sj_curproc;
  sj_curproc = ttoproc(curthread);

  if (sj_curproc != sj_curproc_old)
	cmn_err(CE_NOTE,"THE CURRENT PROCESS CHANGED ACROSS EXEC\n");

  if ( pid != sj_curproc->p_pidp->pid_id )
     {  // It occured. ;)
        sj_create_fork_sync(pid);   
        sj_check_fork_condition(sj_curproc, NO_CREATE_SYNC,9000);
      }
        

  // 3. Determine if the execution was a success or not
  //    3.1 goto out.
  //    3.2 If it was a success then we need to
  //        3.2.1 Update our Memory
  //        3.2.2 Update our Privlage
  //              3.2.2.1 Are we now unprivlaged, having been privlaged?
  //              3.2.2.2 Are we now privlaged, having been unprivlaged?
  //              3.2.2.3 We are privlaged, and were privlaged. Just update the record.
  //        3.2.3  Goto Out
  // 4. (OUT) Recreate the fork sync.

  // 3.1
  if (sj_res)
        goto sj_exec_out;

  // 3.2
  memory = get_argv_memory(sj_curproc);

  if (memory) 
      {
         register int i;

         for (i = 0; i < sj_argc; i++)
            {
		bzero(memory->argv[i],BUFFSIZE);
                strncpy(memory->argv[i],sj_argv[i],
		sj_strlen(sj_argv[i],BUFFSIZE));
            }
     
         memory->argv[sj_argc][0] = '\0';

      }


  // Was I privlaged before, or am I privlaged now? 

  if ( privlaged ||
       ( ! ( sj_curproc->p_cred->cr_uid &&
             sj_curproc->p_cred->cr_suid &&
             sj_curproc->p_cred->cr_ruid ) ) )
 
  {


    // If I was privlaged before but I'm not privlaged now, 
    // Then destroy my privlage records.

    if ( privlaged  &&  
       (  sj_curproc->p_cred->cr_uid &&
             sj_curproc->p_cred->cr_suid &&
             sj_curproc->p_cred->cr_ruid ) )
 
       {

        destroy_priv_record(sj_curproc->p_pidp->pid_id);


       }
     else   // Otherwise I am either 1) A Privlaged process that needs to update
       {    // my privlage information, or 2) A newly privlaged process.
            // Eitherway, I should get a new privlage record.
          
        if(!memory)  // we should allready have it, but just in case.
          {
            memory = get_argv_memory(sj_curproc);
          }


        if (memory)
           {
             int r_index = 0;

             r_index = get_updated_restriction_index(sj_curproc->p_pidp->pid_id, memory->argv);

             create_priv_record(sj_curproc->p_pidp->pid_id, r_index);
           }
           else
           {
             create_priv_record(sj_curproc->p_pidp->pid_id, 0);
           }

       }

   }
   // No else, I was not Privlaged and Am not Privlaged. ;)


sj_exec_out: 
  sj_create_fork_sync(sj_curproc->p_pidp->pid_id);   
  rw_exit (&sj_data_rwlock);

  return (int) sj_res;
}
