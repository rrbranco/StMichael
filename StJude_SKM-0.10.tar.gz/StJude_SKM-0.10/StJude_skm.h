
/* Saint Jude, Solaris Kernel Module.  
 * Verions: 0.10
 *
 * May 13, 2002 - Happy Mothers Day Mom.
 *
 * Copyright: Tim Lawless <lawless@wwjh.net>, All rights Reserved.
 * 
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 * 
 *    Note should be taken that this is considered experimental software.
 *    It is not intended for any purpose other then to be pretty to look
 *    at. Do not feed this source code to your pets, and keep it out of
 *    the hands of kids. Do not expose this code to direct microwave 
 *    radiation. Prolonged exposure to kernel module source code 
 *    can cause irreversable harm.
 *    
 *    You have been warned.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *    Do not modify this Comment.
 */

#define SJ_PRIV_HASH 10
#define SJ_MEMORY_HASH 10
#define SJ_SYNC_HASH 10		// Solaris Only
#define SJ_EXIT_HASH 10		// Solaris Only
#define SJ_EXIT_YIELD_DELAY 10		// Solaris Only
#define MAX_KEY_ELEMENTS 10
#define MAX_RESTRICTIONS_ELEMENTS 10
#define MAX_RESTRICTIONS 256
#define BUFFSIZE 256
#define NULL_ARGV { "","","","","","","" };
#define VERSION "StJude_SKM 0.10"
#define TRUE 1
#define FALSE 0

/* Used for Argv Memory Stuff -- Don't Change Values */
#define CREATE_SYNC 1
#define NO_CREATE_SYNC 0
/* Internal StJude Structures */

typedef struct sj_rulebase SJ_RULEBASE;
typedef struct sj_priv SJ_PRIV;
typedef struct sj_argv_memory SJ_MEMORY;
typedef struct sj_override SJ_OVERRIDE;
typedef struct sj_fork_sync SJ_FORK_SYNC;	// Solaris Only


union intconv_6432 {
      int64_t  int64;
      struct {
             int32_t low;
             int32_t high;
             } int32;
      };

struct sj_priv {
    pid_t pid;
    struct sj_rulebase *restriction;
    struct sj_priv *next;
    struct sj_priv *prev;
};

struct sj_argv_memory {
    pid_t pid;
    char argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE];
    struct sj_argv_memory *next;
};


struct sj_rulebase {
    int r_index;
    char *key[MAX_KEY_ELEMENTS];
    char *restrictions[MAX_RESTRICTIONS][MAX_RESTRICTIONS_ELEMENTS + 1];
};


struct sj_override {
    char key[BUFFSIZE];
    int rule_index;
};

struct sj_fork_sync		// Solaris Only
{
    pid_t pid;
    short write_count;
    short read_count;
    krwlock_t proc_lock; 
    SJ_FORK_SYNC *next;
};



/* Internal Privlage Manipulation Utilities */
/* May contain OS Dependent Code... */

struct sj_priv *create_priv_record(pid_t pid, int restriction_index);
int destroy_priv_record(pid_t pid);
struct sj_priv *get_priv_record(pid_t pid, int initilize,int flag);
int check_priv_record(proc_t * p_process,
		      char argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE]);
int check_restriction(char argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE], char
		      *restrictions[MAX_RESTRICTIONS]
		      [MAX_RESTRICTIONS_ELEMENTS + 1]);
int get_updated_restriction_index(pid_t pid,
			  char argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE]);


/* ARGV_MEORY Utilities */

struct sj_argv_memory *create_argv_memory(pid_t pid,
					  char argv[MAX_KEY_ELEMENTS +
						    1][BUFFSIZE]);
int destroy_argv_memory(pid_t pid);
struct sj_argv_memory *get_argv_memory(proc_t * p_process);

// This is considered a memory utility, since we use memory to 
// Detect the need to perform this 'hack'

void sj_check_fork_condition( proc_t * p_process, int flag, int  tag);

/*
 * FORK_SYNC 
 * Syncronization tool to handle the scheduler inversion of fork parent and children 
 * Note: The task_list mutex should not be held when calling. 
 */


void sj_init_fork_sync(void);

//void sj_check_fork_sync(pid_t pid);
//void sj_check_fork_sync(pid_t pid, int i);
void sj_check_fork_sync(proc_t * p_process, int i);

/* Return 1 if fork_sync exists.. 0 if not */

int sj_check_fork_sync_noblock(pid_t pid);

/* Return 1 if successful.. 0 if not */

void sj_create_fork_sync(pid_t pid);

/* Note: Will block until the fork sync is established. */

void sj_destroy_fork_sync(pid_t pid);

/* Set the Number of nanosecs to delay.. A default is set. */
/* A low number reduces latency, but increases system load. */
/* A high number increases system load, but reduces latency. */

void sj_set_fork_sync_delay(unsigned int delay_length);

// Please god, let this be simi-random.

#define SJ_DO_DELAY() 	delay (sj_fork_sync_delay + \
	((((unsigned long) curthread % 47) + \
	((unsigned long) curthread % 91)) % 31 ))

/* Garbage Collection Functions */


/* Internal String Manipulation Utilities -- OS Independent */

int sj_strncmp(char *s1, char *s2, int max_len);
char *sj_substr(char *s, int start, int end);
int sj_strlen(char *s1, int max_len);
int sj_count(char **argv, int max);
int sj_strncpy(char *source, char *dest, int count);


/* OS Dependent Wrapper Function Prototypes */

/* First the place holders for the critical systemcalls */

int (*orig_execve) (char *, char *[], char *[]);
int (*orig_exec) (char *, char *[]);
void (*orig_exit) (int);
int64_t(*orig_fork) (void);
int64_t(*orig_fork1) (void);
int (*orig_setuid) (const uid_t);
int (*orig_seteuid) (const uid_t);
int (*orig_setreuid) (const uid_t, const uid_t);
int64_t(*orig_vfork) (void);

#if defined (_SYSCALL32_IMPL)
int (*orig32_execve) (char *, char *[], char *[]);
int (*orig32_exec) (char *, char *[]);
void (*orig32_exit) (int);
int64_t(*orig32_fork) (void);
int64_t(*orig32_fork1) (void);
int (*orig32_setuid) (const uid_t);
int (*orig32_seteuid) (const uid_t);
int (*orig32_setreuid) (const uid_t, const uid_t);
int64_t(*orig32_vfork) (void);
#endif


/* Next, their replacements. */

int sj_execve(char *filename, char *argv[], char *envp[]);
int sj_exec(char *filename, char *argv[]);
void sj_exit(int error);
int64_t sj_fork1(void);
int64_t sj_fork(void);
int sj_setuid(const uid_t uid);
int sj_seteuid(const uid_t euid);
int sj_setreuid(const uid_t ruid, const uid_t euid);
int64_t sj_vfork(void);



/* Prototype for the Responce Functions */
/* OS Independent Interface -- OS Dependent Code */

int sj_do_response(char *filename, char *argv[], char *envp[]);
