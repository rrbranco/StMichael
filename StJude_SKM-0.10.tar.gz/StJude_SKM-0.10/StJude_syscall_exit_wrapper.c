
/* Saint Jude, Solaris Kernel Module.  
 * Verions: 0.10
 *
 * May 13, 2002 - Happy Mothers Day Mom.
 *
 * Copyright: Tim Lawless <lawless@wwjh.net>, All rights Reserved.
 * 
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 * 
 *    Note should be taken that this is considered experimental software.
 *    It is not intended for any purpose other then to be pretty to look
 *    at. Do not feed this source code to your pets, and keep it out of
 *    the hands of kids. Do not expose this code to direct microwave 
 *    radiation. Prolonged exposure to kernel module source code 
 *    can cause irreversable harm.
 *    
 *    You have been warned.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *    Do not modify this Comment.
 */

#include <sys/types.h>
#include <sys/systm.h>
#include <sys/proc.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/thread.h>
#include "StJude_skm.h"

extern krwlock_t sj_data_rwlock;
extern kmutex_t sj_runlock;
extern ksema_t sj_sema;
extern sj_fork_sync_delay;

void
sj_exit (int error)
{

  proc_t *sj_curproc = ttoproc(curthread);
  int dbc;


#ifdef DEBUG
  cmn_err (CE_NOTE, " (EXIT)----SYSCALL BY %d--------\n", (int) sj_curproc->p_pidp->pid_id );
#endif

dbc = 0;
sj_pre_exit:
mutex_enter(&sj_curproc->p_lock);
rw_enter(&sj_data_rwlock,RW_WRITER);
if (!sema_tryp(&sj_sema))
	{
	  rw_exit(&sj_data_rwlock);
	  mutex_exit(&sj_curproc->p_lock);
#ifdef DEBUG
          if (dbc > 21)
		cmn_err(CE_NOTE,"CAUGHT IN LOOP STATION C\n");
#endif
          SJ_DO_DELAY();

#ifdef DEBUG
          dbc++;
#endif
	  goto sj_pre_exit;
	}
  else
	{
	  while (sema_tryp(&sj_sema));
	  sema_v(&sj_sema);
	  mutex_exit(&sj_curproc->p_lock);
	}

   sj_garbage_collection();

rw_exit(&sj_data_rwlock);

#if defined(__SYSCALL32_IMPL)
  if (sj_curproc->p_mode == DATAMODEL_NATIVE)
      (*orig32_exit)(error);
  else
#endif
  (*orig_exit) (error);

  // should not reach this point.

  return;
}
