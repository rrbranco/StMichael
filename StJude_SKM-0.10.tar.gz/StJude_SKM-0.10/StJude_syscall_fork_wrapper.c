
/* Saint Jude, Solaris Kernel Module.  
 * Verions: 0.10
 *
 * May 13, 2002 - Happy Mothers Day Mom.
 *
 * Copyright: Tim Lawless <lawless@wwjh.net>, All rights Reserved.
 * 
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 * 
 *    Note should be taken that this is considered experimental software.
 *    It is not intended for any purpose other then to be pretty to look
 *    at. Do not feed this source code to your pets, and keep it out of
 *    the hands of kids. Do not expose this code to direct microwave 
 *    radiation. Prolonged exposure to kernel module source code 
 *    can cause irreversable harm.
 *    
 *    You have been warned.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *    Do not modify this Comment.
 */

#include <sys/types.h>
#include <sys/systm.h>
#include <sys/proc.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/thread.h>
#include "StJude_skm.h"


/*
 * 
 * On a fork we will need to check if the process has privlage.
 * If yes, then does it have a privlage record?
 *
 *    If it has privlage and no privlage record, then we shall
 *    presume it is a setuid program. At this point we generate
 *    get the index for its restriction, and generate a privlage 
 *    record.
 *
 * If we do have a privlage record, then we need to generate a
 * generate a privlage record for our guy based on the parent's
 * informaiton. 
 *
 */

extern kmutex_t sj_runlock;
extern krwlock_t sj_data_rwlock;
extern ksema_t sj_sema;
extern sj_fork_sync_delay;
int64_t
sj_fork (void)
{
  union intconv_6432 sj_fork_return;
  proc_t *sj_curproc = ttoproc(curthread);
  register proc_t *p;
  struct sj_argv_memory *memory;
  pid_t parent_pid;
  int dbc;
  char null_argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE] = NULL_ARGV;

#ifdef DEBUG
  cmn_err (CE_NOTE, " (FORK)-----SYSCALL BY %d-----", sj_curproc->p_pidp->pid_id);
#endif

dbc = 0;
sj_pre_fork:
  mutex_enter(&sj_curproc->p_lock);
  rw_enter (&sj_data_rwlock, RW_WRITER);
  if (!sema_tryp(&sj_sema))
        {
          rw_exit(&sj_data_rwlock);
          mutex_exit(&sj_curproc->p_lock);
#ifdef DEBUG
          if (dbc > 20)
          cmn_err(CE_NOTE,"CAUGHT IN LOOP STATION E\n");
#endif
	  SJ_DO_DELAY();
#ifdef DEBUG
          dbc++;
#endif
          goto sj_pre_fork;
        }
  else
        { 
          while(sema_tryp(&sj_sema));
          sema_v(&sj_sema);
          mutex_exit(&sj_curproc->p_lock);
        }


  parent_pid = sj_curproc->p_pidp->pid_id;
  sj_check_fork_condition(sj_curproc, CREATE_SYNC, 4000);
  sj_check_fork_sync (sj_curproc,5);
  rw_exit(&sj_data_rwlock);

#if defined(__SYSCALL32_IMPL)
  if (sj_curproc->p_mode == DATAMODEL_NATIVE)
      sj_fork_return.int64  = (*orig32_fork)();
  else
#endif
  sj_fork_return.int64 = (*orig_fork) ();

          // If the fork failed, or whatever, there may not be
          // A child to find. So bypass all this stuff..

          if ( sj_fork_return.int32.low < 1 || (!sj_curproc->p_child) )
                 goto sj_fork_found_child; 

          p = sj_curproc->p_child;
          do
            {
                if (p->p_pidp->pid_id == sj_fork_return.int32.low )
                {    
                     sj_check_fork_condition(p, 
				CREATE_SYNC, 4600);
                     goto sj_fork_found_child;
                }
                p = p->p_sibling;

            }
           while ( p && p != sj_curproc->p_child );

           cmn_err(CE_WARN,
		"SOMETHING BAD HAPPENED. I CAN NOT FIND MY CHILDREN!\n");

sj_fork_found_child: 

return sj_fork_return.int64; // I am the Child. I get Nothing!
}
