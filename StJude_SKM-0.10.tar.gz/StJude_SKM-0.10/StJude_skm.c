
/* Saint Jude, Solaris Kernel Module.  
 * Verions: 0.10
 *
 * May 13, 2002 - Happy Mothers Day Mom.
 *
 * Copyright: Tim Lawless <lawless@wwjh.net>, All rights Reserved.
 * 
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 * 
 *    Note should be taken that this is considered experimental software.
 *    It is not intended for any purpose other then to be pretty to look
 *    at. Do not feed this source code to your pets, and keep it out of
 *    the hands of kids. Do not expose this code to direct microwave 
 *    radiation. Prolonged exposure to kernel module source code 
 *    can cause irreversable harm.
 *    
 *    You have been warned.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *    Do not modify this Comment.
 */


#include <sys/types.h>
#include <sys/systm.h>		/* for the sysent array */
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/modctl.h>
#include <sys/syscall.h>	/* system call maps */
#include <sys/thread.h>
#include <sys/ksynch.h>
#include "StJude_skm.h"


/* extern struct mod_ops mod_miscops; */

static struct modlmisc sj_modlmisc = {
  &mod_miscops,
  "StJudeSKM" 
};

static struct modlinkage modlinkage = {
  MODREV_1,
  (void *) &sj_modlmisc,
  NULL
};

/* Declare some our our locks */
krwlock_t sj_data_rwlock;
kmutex_t sj_runlock;
ksema_t sj_sema;

/* Saint Jude Data Structures */
extern SJ_PRIV *sj_priv_hash[SJ_PRIV_HASH];
extern SJ_MEMORY *sj_argv_memory_hash[SJ_MEMORY_HASH];

/* Init */
int
_init (void)
{
  proc_t *p;
  int init_return_value;
  int i;
  extern proc_t p0;

  if ((init_return_value = mod_install (&modlinkage)) != 0)
    {
      cmn_err (CE_WARN, "Could not Install Module\n");
      return init_return_value;
    }

  for (i = 0; i < SJ_PRIV_HASH; i++)
    sj_priv_hash[i] = NULL;

  for (i = 0; i < SJ_MEMORY_HASH; i++)
    sj_argv_memory_hash[i] = NULL;

  /* Init our locks */

  rw_init (&sj_data_rwlock, NULL, RW_DRIVER, NULL);
  sema_init (&sj_sema, 1, NULL, SEMA_DRIVER, NULL);

  sj_init_fork_sync ();

#ifndef SILENT
#ifdef LEARNING
  cmn_err (CE_NOTE, "-={ Loading %s (LEARNING MODE) }=-\n", VERSION);
#else
  cmn_err (CE_NOTE, "-={ Loading %s }=-\n",  VERSION);
#endif
#endif

  /* Lock the process list while we take a stroll through it.. */


  if (!(mutex_owned (&sj_runlock)))
    mutex_enter (&sj_runlock);

  rw_enter(&sj_data_rwlock,RW_WRITER);

  //p = practive;
    p = proc_sched;
  do
    {
      SJ_MEMORY *memory;
      char null_argv[MAX_KEY_ELEMENTS + 1][BUFFSIZE] = NULL_ARGV;


      if (!p)
	break;			/* paranoia */
      

      snprintf(null_argv[0],BUFFSIZE,"sj_initproc_%d",(int) p->p_pidp->pid_id);
      memory = create_argv_memory (p->p_pidp->pid_id, null_argv);
      if (!memory)
	{
	  cmn_err (CE_WARN,
		   "Can not init Saint Jude, memory creation failed.");
	  return 1;
	}

      if (!(p->p_cred->cr_uid && p->p_cred->cr_ruid && p->p_cred->cr_suid))
	{
	  SJ_PRIV *priv;
	  SJ_PRIV *priv_check;


	  priv = create_priv_record (p->p_pidp->pid_id, 1);
	  if (!priv)
	    {
	      cmn_err (CE_WARN,
		       "Can not init Saint Jude, priv creation failed.");
	      return 1;
	    }
	  priv_check = get_priv_record (p->p_pidp->pid_id,1,0);
	  if (!priv_check)
	    {
	      cmn_err (CE_WARN, "Cen't get priv that I just created.\n");
	    }

	}

      sj_create_fork_sync (p->p_pidp->pid_id);

      p = p->p_prev;
    }
  while (p); //  p != practive);


  orig_execve = (void *) sysent[SYS_execve].sy_callc;
  orig_exec = (void *) sysent[SYS_exec].sy_callc;

  orig_exit = (void *) sysent[SYS_exit].sy_callc;
  orig_fork = (void *) sysent[SYS_fork].sy_callc;
  orig_vfork = (void *) sysent[SYS_vfork].sy_callc;

  orig_fork1 = (void *) sysent[SYS_fork1].sy_callc;
  orig_setuid = (void *) sysent[SYS_setuid].sy_callc;
  orig_seteuid = (void *) sysent[SYS_seteuid].sy_callc;
  orig_setreuid = (void *) sysent[SYS_setreuid].sy_callc;

#ifdef _SYSCALL32_IMPL
  orig32_execve = (void *) sysent[SYS_execve].sy_callc;
  orig32_exec = (void *) sysent[SYS_exec].sy_callc;

  orig32_exit = (void *) sysent[SYS_exit].sy_callc;
  orig32_fork = (void *) sysent[SYS_fork].sy_callc;
  orig32_vfork = (void *) sysent[SYS_vfork].sy_callc;

  orig32_fork1 = (void *) sysent[SYS_fork1].sy_callc;
  orig32_setuid = (void *) sysent[SYS_setuid].sy_callc;
  orig32_seteuid = (void *) sysent[SYS_seteuid].sy_callc;
  orig32_setreuid = (void *) sysent[SYS_setreuid].sy_callc;
#endif

 

// Need to handle the .sy_call portion to. We can try setting
// To null, but this may cause *cough* bad things to happen.
//

  sysent[SYS_execve].sy_callc = (void *) sj_execve;
  sysent[SYS_execve].sy_call = NULL;
  sysent[SYS_exec].sy_callc = (void *) sj_exec;
  sysent[SYS_exec].sy_call = NULL;
  sysent[SYS_exit].sy_callc = (void *) sj_exit;
  sysent[SYS_exit].sy_call = NULL;
  sysent[SYS_fork].sy_callc = (void *) sj_fork;
  sysent[SYS_fork].sy_call = NULL;
  sysent[SYS_vfork].sy_callc = (void *) sj_vfork;
  sysent[SYS_vfork].sy_call = NULL;
  sysent[SYS_fork1].sy_callc = (void *) sj_fork1;
  sysent[SYS_fork1].sy_call = NULL;
  sysent[SYS_setuid].sy_callc = (void *) sj_setuid;
  sysent[SYS_setuid].sy_call = NULL;
  sysent[SYS_seteuid].sy_callc = (void *) sj_seteuid;
  sysent[SYS_seteuid].sy_call = NULL;
  sysent[SYS_setreuid].sy_callc = (void *) sj_setreuid;
  sysent[SYS_setreuid].sy_call = NULL;

#ifdef _SYSCALL32_IMPL
  sysent32[SYS_execve].sy_callc = (void *) sj_execve;
  sysent32[SYS_execve].sy_call = NULL;
  sysent32[SYS_exec].sy_callc = (void *) sj_exec;
  sysent32[SYS_exec].sy_call = NULL;
  sysent32[SYS_exit].sy_callc = (void *) sj_exit;
  sysent32[SYS_exit].sy_call = NULL;
  sysent32[SYS_fork].sy_callc = (void *) sj_fork;
  sysent32[SYS_fork].sy_call = NULL;
  sysent32[SYS_vfork].sy_callc = (void *) sj_vfork;
  sysent32[SYS_vfork].sy_call = NULL;
  sysent32[SYS_fork1].sy_callc = (void *) sj_fork1;
  sysent32[SYS_fork1].sy_call = NULL;
  sysent32[SYS_setuid].sy_callc = (void *) sj_setuid;
  sysent32[SYS_setuid].sy_call = NULL;
  sysent32[SYS_seteuid].sy_callc = (void *) sj_seteuid;
  sysent32[SYS_seteuid].sy_call = NULL;
  sysent32[SYS_setreuid].sy_callc = (void *) sj_setreuid;
  sysent32[SYS_setreuid].sy_call = NULL;
#endif

  rw_exit(&sj_data_rwlock);
  mutex_exit (&sj_runlock);

#ifndef SILENT
  cmn_err (CE_NOTE, "-={ %s READY }=-\n",  VERSION);
#endif

  return init_return_value;
}


int
_info (struct modinfo *modinfop)
{
  return (mod_info (&modlinkage, modinfop));
}

int
_fini (void)
{
  return -1;
}
