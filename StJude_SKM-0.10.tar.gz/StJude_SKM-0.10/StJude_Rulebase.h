SJ_RULEBASE sj_rulebase[] = { 
	{ 0, {NULL}, {{"NONE", NULL}, {NULL}}},
	{ 1, {NULL}, {{"ALL", NULL}, {NULL}}},
	{ 2, {"/usr/bin/su", NULL}, {{"ALL", NULL}, {NULL}}},
	{ 3, {NULL}, {NULL} } 
};



SJ_OVERRIDE sj_override[] = {
    {"/usr/local/sbin/sshd", 0} ,
    {"/usr/sbin/sshd", 0} ,
    {"/etc/opt/licenses/lmgrd.ste", 0} ,
    {"/usr/lib/nfs/statd", 0} ,
    {"/usr/lib/sysevent/syseventd", 0} ,
    {"/usr/lib/sysevent/syseventconfd", 0} ,
    {"/usr/sbin/rpcbind", 0} ,
    {"/usr/sbin/in.routed", 0} ,
    {"/usr/sadm/lib/smc/bin/smcboot", 0} ,
    {"/usr/lib/lpsched", 0} ,
    {"/usr/lib/autofs/automountd", 0} ,
    {"/usr/lib/sysevent/syseventconfd", 0} ,
    {"/usr/lib/nfs/lockd", 0} ,
    {"/usr/sbin/syslogd", 0} ,
    {"/usr/lib/saf/sac", 0} ,
    {"/usr/lib/saf/ttymon", 0} ,
    {"/usr/sbin/inetd", 0} ,
    {"/usr/sbin/nscd", 0} ,
    {"/usr/sbin/utmpd", 0} ,
    {"/usr/lib/saf/utmpd", 0} ,
    {"/usr/sbin/auditd", 0} ,
    {"/usr/lib/sendmail", 0} ,
    {"/usr/lib/dmi/dmispd", 0} ,
    {"/usr/lib/dmi/snmpXdmid", 0} ,
    {"/usr/dt/bin/dtlogin", 0} ,
    {"", 0}			/* Terminal Value */
};
