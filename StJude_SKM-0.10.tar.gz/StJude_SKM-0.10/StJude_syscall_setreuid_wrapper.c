
/* Saint Jude, Solaris Kernel Module.  
 * Verions: 0.10
 *
 * May 13, 2002 - Happy Mothers Day Mom.
 *
 * Copyright: Tim Lawless <lawless@wwjh.net>, All rights Reserved.
 * 
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 * 
 *    Note should be taken that this is considered experimental software.
 *    It is not intended for any purpose other then to be pretty to look
 *    at. Do not feed this source code to your pets, and keep it out of
 *    the hands of kids. Do not expose this code to direct microwave 
 *    radiation. Prolonged exposure to kernel module source code 
 *    can cause irreversable harm.
 *    
 *    You have been warned.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *    Do not modify this Comment.
 */

#include <sys/types.h>
#include <sys/systm.h>
#include <sys/proc.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/thread.h>
#include "StJude_skm.h"

extern krwlock_t sj_data_rwlock;
extern kmutex_t sj_runlock;
extern ksema_t sj_sema;
extern sj_fork_sync_delay;

/*
 * If we set the uid of the process to both non-root
 * ids then we can not transition back into root.
 * At this point we can then remove the privlage
 * entry from the stuff. 
 */

int
sj_setreuid (uid_t ruid, uid_t euid)
{
  int sj_setreuid_return;
  proc_t *sj_curproc = ttoproc(curthread);
  pid_t pid;
  short privlaged = 0;


#ifdef DEBUG
  cmn_err (CE_NOTE, "(SETREUID)--------SYSCALL BY %d--------\n", (int) sj_curproc->p_pidp->pid_id);
#endif
sj_pre_setreuid:
  mutex_enter(&sj_curproc->p_lock);
  rw_enter (&sj_data_rwlock, RW_WRITER);
  if (!sema_tryp(&sj_sema))
        {
          rw_exit(&sj_data_rwlock);
          mutex_exit(&sj_curproc->p_lock);
	  SJ_DO_DELAY();
          goto sj_pre_setreuid;
        }
  else
        { 
          while(sema_tryp(&sj_sema));
          sema_v(&sj_sema);
          mutex_exit(&sj_curproc->p_lock);
        }


  pid = sj_curproc->p_pidp->pid_id;
  sj_check_fork_condition(sj_curproc, CREATE_SYNC, 6000);
  sj_check_fork_sync (sj_curproc,7);


  if (!(sj_curproc->p_cred->cr_uid &&
	sj_curproc->p_cred->cr_ruid && sj_curproc->p_cred->cr_suid))
    {
      struct sj_priv *priv;

      privlaged = 1;

      priv = get_priv_record (sj_curproc->p_pidp->pid_id,0,RW_WRITER);

      if (!priv)
	{
	  cmn_err (CE_WARN,
		   "Discovered a Privlaged Process Without a Priv Record.");
	  rw_exit (&sj_data_rwlock);
	  return -1;
	}

    }

  while(sema_tryp(&sj_sema));
  sj_destroy_fork_sync(pid);
  rw_exit (&sj_data_rwlock);

#if defined(__SYSCALL32_IMPL)
  if (sj_curproc->p_mode == DATAMODEL_NATIVE)
      sj_setreuid_return  = (*orig32_setreuid)(ruid,euid);
  else
#endif
  sj_setreuid_return = (*orig_setreuid) (ruid, euid);

  rw_enter (&sj_data_rwlock, RW_WRITER);

  if (!sema_tryp(&sj_sema))
	sema_v(&sj_sema);
#ifdef DEBUG
  else
	cmn_err(CE_NOTE,"An Upped Sema in setreuid occured.\n");
#endif

  if ( pid != sj_curproc->p_pidp->pid_id )
      {
#ifdef DEBUG
       cmn_err(CE_NOTE,"Got one of those strange ones in setreuid.\n");
#endif
       sj_create_fork_sync(pid);
       sj_check_fork_condition(sj_curproc,NO_CREATE_SYNC,22000);
      }
  

  if (privlaged && (sj_curproc->p_cred->cr_uid &&
		    sj_curproc->p_cred->cr_ruid && sj_curproc->p_cred->cr_suid))
    {
      destroy_priv_record (sj_curproc->p_pidp->pid_id);

    }


  sj_create_fork_sync(sj_curproc->p_pidp->pid_id);
  rw_exit (&sj_data_rwlock);
  return sj_setreuid_return;

}
