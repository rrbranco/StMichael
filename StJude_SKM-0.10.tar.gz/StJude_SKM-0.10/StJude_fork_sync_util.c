#define __KERNEL__

/* Saint Jude, Solaris Kernel Module.  
 * Verions: 0.10
 *
 * May 13, 2002 - Happy Mothers Day Mom.
 *
 * Copyright: Tim Lawless <lawless@wwjh.net>, All rights Reserved.
 * 
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 2 of
 *    the License, or (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be
 *    useful, but WITHOUT ANY WARRANTY; without even the implied
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *    PURPOSE.  See the GNU General Public License for more details.
 * 
 *    Note should be taken that this is considered experimental software.
 *    It is not intended for any purpose other then to be pretty to look
 *    at. Do not feed this source code to your pets, and keep it out of
 *    the hands of kids. Do not expose this code to direct microwave 
 *    radiation. Prolonged exposure to kernel module source code 
 *    can cause irreversable harm.
 *    
 *    You have been warned.
 *
 *    You should have received a copy of the GNU General Public
 *    License along with this program; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *    USA.
 *      
 *    Do not modify this Comment.
 */

 // Note: Every Function has to be Reenterant!
 //
 /* Find Replacement for kmalloc!!! */

#include <sys/types.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/proc.h>
#include "StJude_skm.h"

#define  DEFAULT_FORK_SYNC_DELAY 5

SJ_FORK_SYNC *sj_fork_sync_hash[SJ_SYNC_HASH];
unsigned long sj_fork_sync_delay;

krwlock_t sj_sync_fork_rwlock;
extern krwlock_t sj_data_rwlock;

void
sj_init_fork_sync (void)
{
  int sj_i;

  for (sj_i = 0; sj_i < SJ_SYNC_HASH; sj_i++)
    sj_fork_sync_hash[sj_i] = NULL;

  rw_init (&sj_sync_fork_rwlock, NULL, RW_DRIVER, NULL);
  sj_set_fork_sync_delay (0);

  return;
}

void
sj_set_fork_sync_delay (unsigned int fork_sync_delay)
{

  if (fork_sync_delay)
    sj_fork_sync_delay = fork_sync_delay;
  else
    sj_fork_sync_delay = DEFAULT_FORK_SYNC_DELAY;

  return;
}

inline int
sj_check_fork_sync_noblock (pid_t pid)
{
  register SJ_FORK_SYNC *fs_ptr;

  for (fs_ptr = sj_fork_sync_hash[((unsigned int) pid % SJ_SYNC_HASH)];
       fs_ptr && fs_ptr->pid != pid; fs_ptr = fs_ptr->next);

  if (fs_ptr && fs_ptr->pid == pid)
    {
      return 1;
    }
  else
    {
      return 0;
    }
}


// 
// This will block the process untill it can verify that we have
// Processed all pending fork tasks. 
//
// ALL locks (argv_memory_rwlock, priv_rwlock, sj_curproc->p_lock, EVERYONE
// should be released before this function is called.
//
inline void
sj_check_fork_sync (proc_t *p_process, int id)
{

  
  unsigned long delay_i = 0;
  proc_t *sj_curproc = ttoproc(curthread);
  krw_t lock_type  = RW_READER;
  
  char  lock_held = 0;

  if (!p_process)
    return;

  if (rw_lock_held(&sj_data_rwlock))
     {
#ifdef DEBUG
        cmn_err(CE_NOTE,"Entered a Check fork Sync with the lock held\n");
#endif
        if (rw_write_held(&sj_data_rwlock))
               lock_type = RW_WRITER; 
        else
               lock_type = RW_READER;
        lock_held = 1;
     }

  rw_enter (&sj_sync_fork_rwlock, RW_READER);
  while (!sj_check_fork_sync_noblock (p_process->p_pidp->pid_id))
    {
#ifdef DEBUG
           if (delay_i > 22)
           {
   		   cmn_err(CE_NOTE,"About to Delay PID (%d) waiting for Sync Count (%d) Point %d. I am %d", 
		(int) p_process->p_pidp->pid_id, delay_i, id,
		sj_curproc->p_pidp->pid_id); 
               if (sj_curproc->p_parent)
                     cmn_err(CE_NOTE,"My Parent is %d.\n",
                              sj_curproc->p_parent->p_pidp->pid_id);
               if (sj_curproc->p_parent == p_process )
                   {
                        struct sj_priv *priv;
                        struct sj_argv_memory *memory;

                        cmn_err(CE_NOTE,"Checking My Parents Status.\n");
                        memory = get_argv_memory(sj_curproc->p_parent);
                        priv = get_priv_record(p_process->p_pidp->pid_id,1,0);
                        if (priv)
                           cmn_err(CE_NOTE,"My Parent has a Priv Record.\n");
                        if (memory)
                           cmn_err(CE_NOTE,"My Parent has a Memory Record.\n");

                        if (!memory && !priv && sj_curproc->p_parent->p_parent)
                           {
                              cmn_err(CE_NOTE,"Checking my Grandparent's status\n");
                        memory = get_argv_memory(sj_curproc->p_parent->p_parent);
                        priv = get_priv_record(sj_curproc->p_parent->p_parent->p_pidp->pid_id,1,0);
                        if (priv)
                           cmn_err(CE_NOTE,"My GrandParent has a Priv Record.\n");
                        if (memory)
                           cmn_err(CE_NOTE,"My GrandParent has a Memory Record.\n");
                            }
		
                   } 

            }
#endif

      rw_exit (&sj_sync_fork_rwlock);
      if (lock_held)  
           rw_exit(&sj_data_rwlock);

#ifdef DEBUG
      cmn_err(CE_NOTE,"Dropped Lock for Delay.\n");
#endif
	  SJ_DO_DELAY();

          if (lock_held)
               rw_enter(&sj_data_rwlock,lock_type);

      rw_enter (&sj_sync_fork_rwlock, RW_READER);

#ifdef DEBUG
	      cmn_err(CE_NOTE,"Regained Lock for Delay.\n");
  	      cmn_err(CE_NOTE,"Delay done waiting for Sync.");
#endif
	    delay_i++;
    }

#ifdef DEBUG
	    cmn_err(CE_NOTE,"Got Fork Sync. (%d)",(int) p_process->p_pidp->pid_id);
#endif

      rw_exit (&sj_sync_fork_rwlock);
      return;
}

void
sj_create_fork_sync (pid_t pid)
{

  if (pid < 0)
       return;

  rw_enter (&sj_sync_fork_rwlock, RW_WRITER);
  if (!sj_check_fork_sync_noblock (pid))
    {
      struct sj_fork_sync *fs_ptr;

      fs_ptr = kmem_alloc (sizeof (SJ_FORK_SYNC), KM_SLEEP);
      bzero(fs_ptr,sizeof(SJ_FORK_SYNC));

      fs_ptr->pid = pid;


       
      // 
      // It may look bad that we are doing this as a linked list and performing
      // sequential searches (above), but actually its faster in the majority
      // of 'real' cases.
      //
      // The reason is that ususlay in a fork()/exec*() combo which is most
      // commonly the case in our tests the reason for a fork call, will
      // respond faster since the recent fork() is at or near the head of the
      // hash's list.
      //
      // A bit of a hit on exits() is ok.. I mean.. I hear more users complain
      // about a program starting slowly then exiting slowly. Infact, 
      // I don't think I have ever heard a user complain about a program 
      // exiting slowly.
      //


      fs_ptr->next = sj_fork_sync_hash[((unsigned int) pid % SJ_SYNC_HASH)];
      sj_fork_sync_hash[((unsigned int) pid % SJ_SYNC_HASH)] = fs_ptr;

#ifdef DEBUG
      cmn_err(CE_NOTE,"Created FORKSYNC for PID (%d).\n",(int) pid);
#endif


    }
    rw_exit (&sj_sync_fork_rwlock);

  return;

}

void
sj_destroy_fork_sync (pid_t pid)
{

  SJ_FORK_SYNC *fs_ptr, *tmp_ptr;

  rw_enter (&sj_sync_fork_rwlock, RW_WRITER);
  if (!sj_check_fork_sync_noblock(pid))
           { 
             rw_exit(&sj_sync_fork_rwlock); 
             return; 
           }

#ifdef DEBUG
  cmn_err(CE_NOTE,"Destroying fork_sync for PID (%d).",(int) pid);
#endif


  for (tmp_ptr = NULL, fs_ptr =
       sj_fork_sync_hash[((unsigned int) pid % SJ_SYNC_HASH)];
       fs_ptr && fs_ptr->pid != pid; tmp_ptr = fs_ptr, fs_ptr = fs_ptr->next);

  if (fs_ptr && fs_ptr->pid == pid)
    {
      if (!tmp_ptr)
	sj_fork_sync_hash[((unsigned int) pid % SJ_SYNC_HASH)] = fs_ptr->next;
      else
	tmp_ptr->next = fs_ptr->next;

      kmem_free (fs_ptr, sizeof (SJ_FORK_SYNC));
    }

  rw_exit (&sj_sync_fork_rwlock);

#ifdef DEBUG
  cmn_err(CE_NOTE,"Destroyed fork_sync for PID (%d).",(int) pid);
#endif

  return;

}
